# ConceptAlive

**"See. Explore. Understand."**

An AI-powered Flutter app that turns Science & Math chapters into cinematic, interactive learning experiences — built as the foundation for a platform that will grow to cover full Science & Math, Classes 6–10.

This is a **production-ready foundation**, not a finished product: the first release ships one chapter (*Force and Laws of Motion*) end-to-end, with every screen built generically so new chapters/subjects/classes are added as **data**, not code.

---

## Getting started

```bash
flutter pub get
flutter run
```

Requires **Flutter 3.27+ / Dart 3.6+** (uses `Color.withValues()`). On an older channel, swap `withValues(alpha: x)` for `withOpacity(x)` throughout `lib/`.

No API keys or backend are required to run this build — everything works fully offline using local placeholder content (see [Architecture](#architecture--future-ai-integration) below).

---

## The learning journey

Every topic follows the same 5-stage flow, rendered by the same generic screens for any current or future topic:

1. **Learn** — `LearnScreen` → grade-appropriate explanation (placeholder text today, Claude API tomorrow)
2. **Watch** — `AnimationScreen` → cinematic animation (placeholder generating→ready flow today, Higgsfield API tomorrow)
3. **Experiment** — `ExperimentScreen` → live slider-driven simulation (F = ma demo included, reusable for angle/gravity/velocity/friction sims)
4. **Practice** — `QuizScreen` → adaptive MCQ engine with instant feedback
5. **Master** — reflected via `ProgressScreen`, XP, streaks, and achievements

---

## Architecture & future AI integration

```
lib/
  models/      Pure data classes (Subject, Chapter, Topic, Quiz, Progress)
  services/    Abstract interfaces + local implementations — THE integration seam
  providers/   State management (Provider/ChangeNotifier) — screens depend only on these
  routes/      go_router config, all parameterized by id (no per-chapter routes)
  screens/     One generic screen per journey stage — works for any topic
  widgets/     Reusable UI atoms (cards, buttons, tiles, sliders, MCQ options)
  theme/       Centralized colors, type scale, ThemeData (light + dark)
  utils/       Constants & extensions
```

### Adding a new chapter or subject
Add a new `ChapterModel`/`SubjectModel` entry inside `LocalContentService` (or its future backend equivalent) — **no screen code changes**. `ChapterScreen`, `TopicScreen`, and every journey-stage screen render purely from the data they're given.

### Plugging in Claude for real explanations
`ContentService.getLearnExplanation()` already accepts `learnPromptKey` + `gradeLevel`. Replace `LocalContentService` with a `ClaudeContentService` that calls the Messages API with a prompt built from those two params, and register it in `main.dart`:

```dart
ChangeNotifierProvider(create: (_) => ContentProvider(ClaudeContentService())),
```

### Plugging in Higgsfield for real animations
`AnimationService.getAnimation()` returns an `AnimationResult(status, videoUrl)`. Replace `MockAnimationService` with a real client that creates a render job, polls it, and returns the finished `videoUrl` — `AnimationScreen` already handles the generating → ready UI states and just needs a real URL to hand to a video player (chewie/video_player are already in `pubspec.yaml`).

### Plugging in Firebase (Auth + Firestore + sync)
`ProgressService` is the seam: swap `LocalProgressService`'s `SharedPreferences` calls for Firestore reads/writes with the same method signatures (`loadProgress`, `saveXp`, `markTopicComplete`). Add `FirebaseAuth` for sign-in and thread the resulting `uid` into `ProgressService` calls.

### Adaptive, AI-generated quizzes
`QuizService.generateQuiz()` already accepts a `masteryLevel` parameter. A future `ClaudeQuizService` can use the student's recent scores (tracked via `ProgressProvider`) to request harder/easier questions from Claude, without `QuizScreen` changing at all.

---

## Design system

- **Material 3**, light + dark mode (toggle in Profile, persisted via `SharedPreferences`)
- Display font: **Baloo 2** (friendly/rounded) · Body font: **Inter** (clean/readable)
- Gradient-driven subject theming (`AppColors.gradientForSubject`)
- Glassmorphism (`GlassCard`), soft shadows, rounded-corner scale (`AppTheme.radiusSm/Md/Lg/Xl`)
- `flutter_animate` micro-interactions throughout; confetti on quiz success

---

## Known placeholders (by design)

- Illustrations are emoji-based placeholders — swap for real art/Lottie/AI-generated imagery per topic without touching layout code.
- The animation player shows a styled placeholder instead of a real video; wire up `video_player`/`chewie` once Higgsfield returns real URLs.
- Only one chapter ships; `_ComingSoonCard` on the Science screen signals more are coming.
- Progress/XP/streak data is stored locally per-device; Firestore sync is not yet wired.

## Not yet included (intentionally out of scope for this build)
Firebase project setup, real API keys/clients, app icons/splash native assets, and store listing assets — these are integration/config steps for you to complete when ready to connect real backends.
