import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/theme_provider.dart';
import 'providers/content_provider.dart';
import 'providers/progress_provider.dart';
import 'services/content_service.dart';
import 'services/animation_service.dart';
import 'services/quiz_service.dart';
import 'services/progress_service.dart';
import 'theme/app_theme.dart';
import 'routes/app_routes.dart';
import 'utils/constants.dart';

void main() {
  runApp(const ConceptAliveApp());
}

/// Root widget. All future backend integrations (Claude API, Higgsfield
/// API, Firebase) are wired in exactly one place: the Provider list below.
/// Swap `LocalContentService()` for `ClaudeContentService()`, etc., and
/// nothing else in the app needs to change.
class ConceptAliveApp extends StatelessWidget {
  const ConceptAliveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => ContentProvider(LocalContentService())),
        ChangeNotifierProvider(create: (_) => ProgressProvider(LocalProgressService())),
        Provider<AnimationService>(create: (_) => MockAnimationService()),
        Provider<QuizService>(create: (_) => LocalQuizService()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) {
          return MaterialApp.router(
            title: AppConstants.appName,
            debugShowCheckedModeBanner: false,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: themeProvider.mode,
            routerConfig: AppRoutes.router,
          );
        },
      ),
    );
  }
}
