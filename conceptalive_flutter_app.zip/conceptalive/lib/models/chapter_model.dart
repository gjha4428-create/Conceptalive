import 'topic_model.dart';

/// A chapter belongs to a subject and contains an ordered list of topics.
/// New chapters (e.g. "Gravitation", "Light") are added purely as data —
/// ChapterScreen/TopicScreen render any chapter without modification.
class ChapterModel {
  final String id;
  final String subjectId;
  final String classLevel; // e.g. "Class 8"
  final String title;
  final String description;
  final String coverEmoji; // placeholder illustration
  final DifficultyLevel difficulty;
  final int estimatedMinutes;
  final List<TopicModel> topics;

  const ChapterModel({
    required this.id,
    required this.subjectId,
    required this.classLevel,
    required this.title,
    required this.description,
    required this.coverEmoji,
    required this.difficulty,
    required this.estimatedMinutes,
    required this.topics,
  });

  int get completedTopicsCount => topics.where((t) => t.isCompleted).length;

  double get progress =>
      topics.isEmpty ? 0 : completedTopicsCount / topics.length;
}
