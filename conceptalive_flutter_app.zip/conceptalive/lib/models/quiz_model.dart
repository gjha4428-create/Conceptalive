/// A single multiple-choice question. In production these will be
/// generated on-demand by the Claude API based on the student's mastery
/// level (see QuizService.generateQuiz). For now, curated placeholder
/// question banks live in ContentService.
class QuizQuestion {
  final String id;
  final String question;
  final List<String> options;
  final int correctIndex;
  final String explanation; // shown after answering, reinforces the concept

  const QuizQuestion({
    required this.id,
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.explanation,
  });
}

class QuizModel {
  final String id;
  final String topicId;
  final List<QuizQuestion> questions;

  const QuizModel({
    required this.id,
    required this.topicId,
    required this.questions,
  });
}

/// Captures a completed quiz attempt for progress tracking / adaptive
/// difficulty decisions.
class QuizAttemptResult {
  final String quizId;
  final int correctCount;
  final int totalCount;
  final DateTime completedAt;

  const QuizAttemptResult({
    required this.quizId,
    required this.correctCount,
    required this.totalCount,
    required this.completedAt,
  });

  double get scorePercent => totalCount == 0 ? 0 : correctCount / totalCount * 100;
}
