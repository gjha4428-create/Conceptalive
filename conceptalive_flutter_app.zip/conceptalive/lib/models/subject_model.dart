import 'package:flutter/material.dart';

/// Top-level subject (Science, Mathematics, ...).
/// New subjects are added by creating a new SubjectModel entry in
/// ContentService — no screen code needs to change.
class SubjectModel {
  final String id; // e.g. "science", "math"
  final String name;
  final String tagline;
  final IconData icon;
  final String gradientKey; // resolved to a gradient via AppColors
  final int totalChapters;
  final int completedChapters;

  const SubjectModel({
    required this.id,
    required this.name,
    required this.tagline,
    required this.icon,
    required this.gradientKey,
    required this.totalChapters,
    required this.completedChapters,
  });

  double get progress => totalChapters == 0 ? 0 : completedChapters / totalChapters;
}
