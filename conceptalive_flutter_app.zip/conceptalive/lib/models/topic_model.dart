/// Difficulty tiers shared across chapters/topics.
enum DifficultyLevel { easy, medium, hard }

extension DifficultyLevelX on DifficultyLevel {
  String get label {
    switch (this) {
      case DifficultyLevel.easy:
        return 'Easy';
      case DifficultyLevel.medium:
        return 'Medium';
      case DifficultyLevel.hard:
        return 'Hard';
    }
  }
}

/// A single learning topic inside a chapter (e.g. "Newton's First Law").
/// Each topic drives the 5-stage journey: Learn -> Watch -> Experiment ->
/// Practice -> Master. The journey stages are intentionally generic (not
/// hardcoded per-topic) so any future topic automatically gets the same
/// flow by simply providing this data.
class TopicModel {
  final String id;
  final String chapterId;
  final int orderIndex;
  final String title;
  final String shortDescription;
  final String heroEmoji; // placeholder for illustration until real assets/AI images exist
  final int estimatedMinutes;
  final DifficultyLevel difficulty;
  final double progress; // 0.0 - 1.0
  final bool isCompleted;
  final bool isLocked;

  // Content placeholders — designed to be filled by ContentService,
  // which in production will call the Claude API.
  final String learnPromptKey; // key ContentService uses to fetch/generate explanation
  final String animationPromptKey; // key AnimationService uses w/ Higgsfield
  final String experimentType; // e.g. "force_mass_acceleration"
  final String quizPromptKey;

  const TopicModel({
    required this.id,
    required this.chapterId,
    required this.orderIndex,
    required this.title,
    required this.shortDescription,
    required this.heroEmoji,
    required this.estimatedMinutes,
    required this.difficulty,
    this.progress = 0.0,
    this.isCompleted = false,
    this.isLocked = false,
    required this.learnPromptKey,
    required this.animationPromptKey,
    required this.experimentType,
    required this.quizPromptKey,
  });

  TopicModel copyWith({
    double? progress,
    bool? isCompleted,
    bool? isLocked,
  }) {
    return TopicModel(
      id: id,
      chapterId: chapterId,
      orderIndex: orderIndex,
      title: title,
      shortDescription: shortDescription,
      heroEmoji: heroEmoji,
      estimatedMinutes: estimatedMinutes,
      difficulty: difficulty,
      progress: progress ?? this.progress,
      isCompleted: isCompleted ?? this.isCompleted,
      isLocked: isLocked ?? this.isLocked,
      learnPromptKey: learnPromptKey,
      animationPromptKey: animationPromptKey,
      experimentType: experimentType,
      quizPromptKey: quizPromptKey,
    );
  }
}
