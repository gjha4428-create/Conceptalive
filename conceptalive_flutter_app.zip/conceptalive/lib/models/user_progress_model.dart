/// A single unlockable achievement / badge.
class AchievementModel {
  final String id;
  final String title;
  final String description;
  final String emoji;
  final bool isUnlocked;

  const AchievementModel({
    required this.id,
    required this.title,
    required this.description,
    required this.emoji,
    this.isUnlocked = false,
  });

  AchievementModel copyWith({bool? isUnlocked}) => AchievementModel(
        id: id,
        title: title,
        description: description,
        emoji: emoji,
        isUnlocked: isUnlocked ?? this.isUnlocked,
      );
}

/// Aggregated learner progress. This is the single source of truth that
/// the Progress screen, Home screen streak widget, and Profile screen all
/// read from. In production this will sync with Firestore per user.
class UserProgressModel {
  final String userName;
  final int currentStreakDays;
  final int longestStreakDays;
  final int totalXp;
  final int level;
  final List<DateTime> activityLog; // days the student studied
  final List<AchievementModel> achievements;
  final Map<String, double> chapterProgress; // chapterId -> 0..1

  const UserProgressModel({
    required this.userName,
    required this.currentStreakDays,
    required this.longestStreakDays,
    required this.totalXp,
    required this.level,
    required this.activityLog,
    required this.achievements,
    required this.chapterProgress,
  });

  int get xpToNextLevel => (level * 500) - totalXp.remainder(level * 500);
}
