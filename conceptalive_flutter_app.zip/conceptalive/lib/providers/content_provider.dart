import 'package:flutter/material.dart';
import '../models/subject_model.dart';
import '../models/chapter_model.dart';
import '../models/topic_model.dart';
import '../services/content_service.dart';

/// Exposes ContentService data to the widget tree with loading states.
/// Screens depend only on this provider — swapping ContentService's
/// implementation (e.g. to a real Claude-backed API client) requires no
/// screen changes.
class ContentProvider extends ChangeNotifier {
  final ContentService _service;
  ContentProvider(this._service);

  List<SubjectModel> subjects = [];
  Map<String, List<ChapterModel>> _chaptersBySubject = {};
  bool isLoadingSubjects = false;

  Future<void> loadSubjects() async {
    isLoadingSubjects = true;
    notifyListeners();
    subjects = await _service.getSubjects();
    isLoadingSubjects = false;
    notifyListeners();
  }

  Future<List<ChapterModel>> chaptersFor(String subjectId) async {
    if (_chaptersBySubject.containsKey(subjectId)) {
      return _chaptersBySubject[subjectId]!;
    }
    final chapters = await _service.getChaptersForSubject(subjectId);
    _chaptersBySubject[subjectId] = chapters;
    return chapters;
  }

  Future<ChapterModel?> chapterById(String id) => _service.getChapterById(id);

  Future<TopicModel?> topicById(String id) => _service.getTopicById(id);

  Future<String> learnExplanation(String learnPromptKey, {String gradeLevel = 'Class 9'}) {
    return _service.getLearnExplanation(learnPromptKey: learnPromptKey, gradeLevel: gradeLevel);
  }
}
