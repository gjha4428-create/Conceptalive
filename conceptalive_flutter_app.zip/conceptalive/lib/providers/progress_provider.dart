import 'package:flutter/material.dart';
import '../models/user_progress_model.dart';
import '../services/progress_service.dart';

class ProgressProvider extends ChangeNotifier {
  final ProgressService _service;
  ProgressProvider(this._service);

  UserProgressModel? progress;
  bool isLoading = false;

  Future<void> load() async {
    isLoading = true;
    notifyListeners();
    progress = await _service.loadProgress();
    isLoading = false;
    notifyListeners();
  }

  Future<void> addXp(int amount) async {
    if (progress == null) return;
    final newXp = progress!.totalXp + amount;
    await _service.saveXp(newXp);
    progress = UserProgressModel(
      userName: progress!.userName,
      currentStreakDays: progress!.currentStreakDays,
      longestStreakDays: progress!.longestStreakDays,
      totalXp: newXp,
      level: (newXp / 500).floor() + 1,
      activityLog: progress!.activityLog,
      achievements: progress!.achievements,
      chapterProgress: progress!.chapterProgress,
    );
    notifyListeners();
  }
}
