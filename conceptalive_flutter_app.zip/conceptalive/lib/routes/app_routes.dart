import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../screens/splash/splash_screen.dart';
import '../screens/root/root_shell.dart';
import '../screens/science/science_screen.dart';
import '../screens/chapter/chapter_screen.dart';
import '../screens/topic/topic_screen.dart';
import '../screens/learn/learn_screen.dart';
import '../screens/animation/animation_screen.dart';
import '../screens/experiment/experiment_screen.dart';
import '../screens/quiz/quiz_screen.dart';
import '../screens/quiz/quiz_result_screen.dart';
import '../models/quiz_model.dart';

/// Centralized route table. New chapters/topics don't need new routes —
/// they're all parameterized by id, so content growth never touches
/// routing code.
class AppRoutes {
  AppRoutes._();

  static const splash = '/';
  static const home = '/home';
  static const science = '/science';
  static const chapter = '/chapter/:chapterId';
  static const topic = '/topic/:topicId';
  static const learn = '/topic/:topicId/learn';
  static const animation = '/topic/:topicId/watch';
  static const experiment = '/topic/:topicId/experiment';
  static const quiz = '/topic/:topicId/quiz';
  static const quizResult = '/quiz-result';

  static String chapterPath(String id) => '/chapter/$id';
  static String topicPath(String id) => '/topic/$id';
  static String learnPath(String id) => '/topic/$id/learn';
  static String animationPath(String id) => '/topic/$id/watch';
  static String experimentPath(String id) => '/topic/$id/experiment';
  static String quizPath(String id) => '/topic/$id/quiz';

  static final GoRouter router = GoRouter(
    initialLocation: splash,
    routes: [
      GoRoute(
        path: splash,
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: home,
        builder: (context, state) => const RootShell(),
      ),
      GoRoute(
        path: science,
        builder: (context, state) => const ScienceScreen(),
      ),
      GoRoute(
        path: chapter,
        builder: (context, state) => ChapterScreen(
          chapterId: state.pathParameters['chapterId']!,
        ),
      ),
      GoRoute(
        path: topic,
        builder: (context, state) => TopicScreen(
          topicId: state.pathParameters['topicId']!,
        ),
      ),
      GoRoute(
        path: learn,
        builder: (context, state) => LearnScreen(
          topicId: state.pathParameters['topicId']!,
        ),
      ),
      GoRoute(
        path: animation,
        builder: (context, state) => AnimationScreen(
          topicId: state.pathParameters['topicId']!,
        ),
      ),
      GoRoute(
        path: experiment,
        builder: (context, state) => ExperimentScreen(
          topicId: state.pathParameters['topicId']!,
        ),
      ),
      GoRoute(
        path: quiz,
        builder: (context, state) => QuizScreen(
          topicId: state.pathParameters['topicId']!,
        ),
      ),
      GoRoute(
        path: quizResult,
        builder: (context, state) => QuizResultScreen(
          result: state.extra as QuizAttemptResult,
        ),
      ),
    ],
  );
}
