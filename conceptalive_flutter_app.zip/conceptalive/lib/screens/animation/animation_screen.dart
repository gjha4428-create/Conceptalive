import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/topic_model.dart';
import '../../providers/content_provider.dart';
import '../../services/animation_service.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../routes/app_routes.dart';
import '../../widgets/common/app_button.dart';

/// The "Watch" stage — placeholder for a Higgsfield-generated cinematic
/// animation. Shows a realistic generating -> ready flow so the future
/// integration only needs to supply a real video URL via AnimationService.
class AnimationScreen extends StatefulWidget {
  final String topicId;
  const AnimationScreen({super.key, required this.topicId});

  @override
  State<AnimationScreen> createState() => _AnimationScreenState();
}

class _AnimationScreenState extends State<AnimationScreen> {
  TopicModel? _topic;
  AnimationResult? _result;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final content = context.read<ContentProvider>();
    final animationService = context.read<AnimationService>();
    final topic = await content.topicById(widget.topicId);
    if (topic == null) return;
    setState(() => _topic = topic);
    final result = await animationService.getAnimation(topic.animationPromptKey);
    if (!mounted) return;
    setState(() => _result = result);
  }

  @override
  Widget build(BuildContext context) {
    final ready = _result?.status == AnimationStatus.ready;
    return Scaffold(
      appBar: AppBar(title: Text(_topic?.title ?? 'Watch')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AspectRatio(
                aspectRatio: 16 / 10,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: AppColors.heroDarkGradient,
                    borderRadius: BorderRadius.circular(AppTheme.radiusXl),
                  ),
                  child: Center(
                    child: ready ? _buildReady(context) : _buildGenerating(context),
                  ),
                ),
              ).animate().fadeIn(duration: 400.ms),
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.secondary.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.movie_creation_outlined, size: 14, color: AppColors.secondary),
                    const SizedBox(width: 6),
                    Text('Cinematic visuals powered by Higgsfield',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.secondary)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text(
                ready
                    ? 'This short animation visually breaks down the concept step by step — pause anytime to explore a frame in the upcoming Experiment stage.'
                    : 'We\'re generating a beautiful, concept-accurate animation for this topic. This usually takes just a few seconds.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const Spacer(),
              if (_topic != null)
                PrimaryButton(
                  label: 'Try the Experiment',
                  icon: Icons.science_rounded,
                  color: AppColors.accent,
                  onTap: () => context.push(AppRoutes.experimentPath(_topic!.id)),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGenerating(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(
          width: 40, height: 40,
          child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white),
        ),
        const SizedBox(height: 16),
        const Text('Generating animation…', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _buildReady(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.18), shape: BoxShape.circle),
          child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 36),
        ).animate().scale(duration: 400.ms, curve: Curves.easeOutBack),
        const SizedBox(height: 14),
        const Text('🎬', style: TextStyle(fontSize: 30)),
        const SizedBox(height: 6),
        Text('Video player placeholder', style: TextStyle(color: Colors.white.withValues(alpha: 0.7), fontSize: 12)),
      ],
    );
  }
}
