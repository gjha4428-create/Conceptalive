import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/chapter_model.dart';
import '../../providers/content_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../utils/constants.dart';
import '../../utils/extensions.dart';
import '../../routes/app_routes.dart';
import '../../widgets/chapter/topic_tile.dart';

class ChapterScreen extends StatefulWidget {
  final String chapterId;
  const ChapterScreen({super.key, required this.chapterId});

  @override
  State<ChapterScreen> createState() => _ChapterScreenState();
}

class _ChapterScreenState extends State<ChapterScreen> {
  late Future<ChapterModel?> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<ContentProvider>().chapterById(widget.chapterId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<ChapterModel?>(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final chapter = snapshot.data;
          if (chapter == null) {
            return const Center(child: Text('Chapter not found'));
          }
          return CustomScrollView(
            slivers: [
              SliverAppBar(
                pinned: true,
                expandedHeight: 210,
                backgroundColor: AppColors.scienceStart,
                iconTheme: const IconThemeData(color: Colors.white),
                flexibleSpace: FlexibleSpaceBar(
                  background: Container(
                    decoration: const BoxDecoration(gradient: AppColors.scienceGradient),
                    child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 40, 20, 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(chapter.coverEmoji, style: const TextStyle(fontSize: 46)),
                            const SizedBox(height: 8),
                            Text(chapter.title,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                _HeaderChip(icon: Icons.school_rounded, label: chapter.classLevel),
                                const SizedBox(width: 8),
                                _HeaderChip(icon: Icons.timer_outlined, label: chapter.estimatedMinutes.asMinutesLabel),
                                const SizedBox(width: 8),
                                _HeaderChip(icon: Icons.bar_chart_rounded, label: chapter.difficulty.label),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(
                      AppConstants.screenPaddingH, 20, AppConstants.screenPaddingH, 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(chapter.description, style: Theme.of(context).textTheme.bodyLarge),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: LinearProgressIndicator(
                                value: chapter.progress == 0 ? 0.02 : chapter.progress,
                                minHeight: 8,
                                backgroundColor: Theme.of(context).dividerColor,
                                valueColor: const AlwaysStoppedAnimation(AppColors.secondary),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Text('${chapter.completedTopicsCount}/${chapter.topics.length} topics',
                              style: Theme.of(context).textTheme.bodySmall),
                        ],
                      ),
                      const SizedBox(height: 24),
                      Text('Topics', style: Theme.of(context).textTheme.headlineSmall),
                      const SizedBox(height: 12),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(
                    AppConstants.screenPaddingH, 0, AppConstants.screenPaddingH, 40),
                sliver: SliverList.separated(
                  itemCount: chapter.topics.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, i) {
                    final topic = chapter.topics[i];
                    return TopicTile(
                      topic: topic,
                      onTap: () => context.push(AppRoutes.topicPath(topic.id)),
                    ).animate().fadeIn(delay: (60 * i).ms, duration: 350.ms).moveX(begin: 12, end: 0);
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _HeaderChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _HeaderChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.22),
        borderRadius: BorderRadius.circular(AppTheme.radiusSm),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: Colors.white),
          const SizedBox(width: 4),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
