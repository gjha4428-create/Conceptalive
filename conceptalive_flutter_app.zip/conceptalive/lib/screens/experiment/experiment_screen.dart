import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../models/topic_model.dart';
import '../../providers/content_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';

/// The "Experiment" stage — an interactive simulation where students drag
/// sliders (force, mass, angle, speed, gravity, etc.) and immediately see
/// the effect. Built as a reusable "SimulationCanvas + VariableSlider"
/// pair so any future experimentType can plug in its own physics function
/// without rewriting the screen.
class ExperimentScreen extends StatefulWidget {
  final String topicId;
  const ExperimentScreen({super.key, required this.topicId});

  @override
  State<ExperimentScreen> createState() => _ExperimentScreenState();
}

class _ExperimentScreenState extends State<ExperimentScreen> {
  TopicModel? _topic;

  // Generic variable state — reusable across experiment types.
  double _force = 20; // Newtons
  double _mass = 5; // kg

  @override
  void initState() {
    super.initState();
    context.read<ContentProvider>().topicById(widget.topicId).then((t) {
      if (mounted) setState(() => _topic = t);
    });
  }

  double get _acceleration => _mass == 0 ? 0 : _force / _mass;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_topic?.title ?? 'Experiment')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.accent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.touch_app_rounded, size: 14, color: AppColors.accent),
                  const SizedBox(width: 6),
                  Text('Move the sliders and watch it react live',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Color(0xFFB8860B))),
                ],
              ),
            ),
            const SizedBox(height: 18),

            // Simulation canvas
            _SimulationCanvas(force: _force, mass: _mass, acceleration: _acceleration)
                .animate().fadeIn(duration: 400.ms),

            const SizedBox(height: 24),
            Text('Variables', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),

            _VariableSlider(
              label: 'Force',
              unit: 'N',
              value: _force,
              min: 0,
              max: 100,
              color: AppColors.primary,
              emoji: '💪',
              onChanged: (v) => setState(() => _force = v),
            ),
            const SizedBox(height: 16),
            _VariableSlider(
              label: 'Mass',
              unit: 'kg',
              value: _mass,
              min: 1,
              max: 50,
              color: AppColors.secondary,
              emoji: '🧱',
              onChanged: (v) => setState(() => _mass = v),
            ),

            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardTheme.color,
                borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                border: Border.all(color: Theme.of(context).dividerColor),
              ),
              child: Row(
                children: [
                  const Text('🧮', style: TextStyle(fontSize: 22)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: RichText(
                      text: TextSpan(
                        style: Theme.of(context).textTheme.bodyMedium,
                        children: [
                          const TextSpan(text: 'F = m × a  →  a = F ÷ m  =  '),
                          TextSpan(
                            text: '${_acceleration.toStringAsFixed(2)} m/s²',
                            style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                'This is a reusable simulation shell — future experiments (angle, gravity, surface friction, velocity) plug into the same component structure.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SimulationCanvas extends StatelessWidget {
  final double force;
  final double mass;
  final double acceleration;

  const _SimulationCanvas({required this.force, required this.mass, required this.acceleration});

  @override
  Widget build(BuildContext context) {
    // Visualize acceleration as how far/fast a block "shoots" — purely
    // illustrative, not physically simulated in real time (yet).
    final travel = (acceleration.clamp(0, 20) / 20) * 200;

    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroDarkGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
      ),
      clipBehavior: Clip.hardEdge,
      child: Stack(
        children: [
          Positioned(
            bottom: 20,
            left: 20,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              curve: Curves.easeOut,
              transform: Matrix4.translationValues(travel, 0, 0),
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(color: AppColors.primary.withValues(alpha: 0.5), blurRadius: 16, offset: const Offset(0, 6)),
                ],
              ),
              alignment: Alignment.center,
              child: const Text('📦', style: TextStyle(fontSize: 24)),
            ),
          ),
          Positioned(
            left: 20,
            bottom: 90,
            child: Text('a = ${acceleration.toStringAsFixed(1)} m/s²',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(height: 20, color: Colors.white.withValues(alpha: 0.06)),
          ),
        ],
      ),
    );
  }
}

class _VariableSlider extends StatelessWidget {
  final String label;
  final String unit;
  final String emoji;
  final double value;
  final double min;
  final double max;
  final Color color;
  final ValueChanged<double> onChanged;

  const _VariableSlider({
    required this.label,
    required this.unit,
    required this.emoji,
    required this.value,
    required this.min,
    required this.max,
    required this.color,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Text(label, style: Theme.of(context).textTheme.titleMedium),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: color.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(10)),
                child: Text('${value.toStringAsFixed(0)} $unit',
                    style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13)),
              ),
            ],
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: color,
              thumbColor: color,
              overlayColor: color.withValues(alpha: 0.15),
              inactiveTrackColor: color.withValues(alpha: 0.15),
            ),
            child: Slider(value: value, min: min, max: max, onChanged: onChanged),
          ),
        ],
      ),
    );
  }
}
