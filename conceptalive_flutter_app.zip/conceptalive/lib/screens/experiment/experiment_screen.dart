import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/topic_model.dart';
import '../../providers/content_provider.dart';
import 'experiments/action_reaction_experiment.dart';
import 'experiments/balanced_forces_experiment.dart';
import 'experiments/force_mass_acceleration_experiment.dart';
import 'experiments/inertia_experiment.dart';
import 'experiments/momentum_experiment.dart';

/// The "Experiment" stage — hosts a distinct interactive simulation per
/// topic, selected by [TopicModel.experimentType]. Each experiment type
/// is its own self-contained widget under experiments/, so adding a new
/// topic with a new experiment type only means adding one new widget and
/// one new switch case here — no other screen code changes.
class ExperimentScreen extends StatefulWidget {
  final String topicId;
  const ExperimentScreen({super.key, required this.topicId});

  @override
  State<ExperimentScreen> createState() => _ExperimentScreenState();
}

class _ExperimentScreenState extends State<ExperimentScreen> {
  TopicModel? _topic;

  @override
  void initState() {
    super.initState();
    context.read<ContentProvider>().topicById(widget.topicId).then((t) {
      if (mounted) setState(() => _topic = t);
    });
  }

  Widget _buildExperimentBody(TopicModel topic) {
    switch (topic.experimentType) {
      case 'balanced_forces':
        return const BalancedForcesExperiment();
      case 'inertia_sim':
        return const InertiaExperiment();
      case 'action_reaction':
        return const ActionReactionExperiment();
      case 'momentum_collision':
        return const MomentumExperiment();
      case 'push_pull_force':
      case 'force_mass_acceleration':
      default:
        return const ForceMassAccelerationExperiment();
    }
  }

  @override
  Widget build(BuildContext context) {
    final topic = _topic;
    return Scaffold(
      appBar: AppBar(title: Text(topic?.title ?? 'Experiment')),
      body: SafeArea(
        child: topic == null
            ? const Center(child: CircularProgressIndicator())
            : _buildExperimentBody(topic),
      ),
    );
  }
}
