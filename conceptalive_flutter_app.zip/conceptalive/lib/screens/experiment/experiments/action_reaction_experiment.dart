import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import 'experiment_widgets.dart';

/// Newton's Third Law simulation: two skaters push off each other. The
/// push force is always equal and opposite (action = reaction), but the
/// lighter skater flies back much further/faster than the heavier one —
/// showing that equal forces don't mean equal motion.
class ActionReactionExperiment extends StatefulWidget {
  const ActionReactionExperiment({super.key});

  @override
  State<ActionReactionExperiment> createState() => _ActionReactionExperimentState();
}

class _ActionReactionExperimentState extends State<ActionReactionExperiment> {
  double _massA = 30; // kg, lighter skater
  double _massB = 60; // kg, heavier skater
  bool _pushed = false;

  double get _speedA => _pushed ? (600 / _massA).clamp(2, 40) : 0;
  double get _speedB => _pushed ? (600 / _massB).clamp(2, 40) : 0;

  void _push() => setState(() => _pushed = true);
  void _reset() => setState(() => _pushed = false);

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ExperimentHintBanner(text: 'Tap "Push Off" and watch each skater slide'),
        const SizedBox(height: 18),
        _SkatersCanvas(speedA: _speedA, speedB: _speedB, pushed: _pushed).animate().fadeIn(duration: 400.ms),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _push,
                icon: const Icon(Icons.compare_arrows_rounded),
                label: const Text('Push Off'),
              ),
            ),
            const SizedBox(width: 12),
            OutlinedButton.icon(
              onPressed: _reset,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Reset'),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Text('Variables', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        ExperimentSlider(
          label: 'Skater A mass',
          unit: 'kg',
          value: _massA,
          min: 20,
          max: 100,
          color: AppColors.secondary,
          emoji: '🔵',
          onChanged: (v) => setState(() {
            _massA = v;
            _pushed = false;
          }),
        ),
        const SizedBox(height: 16),
        ExperimentSlider(
          label: 'Skater B mass',
          unit: 'kg',
          value: _massB,
          min: 20,
          max: 100,
          color: AppColors.error,
          emoji: '🔴',
          onChanged: (v) => setState(() {
            _massB = v;
            _pushed = false;
          }),
        ),
        const SizedBox(height: 20),
        ExperimentFormulaCard(
          emoji: '⚡',
          child: Text(
            _pushed
                ? 'Both push with the same force, but the lighter skater (${_massA <= _massB ? "A" : "B"}) speeds away faster — same force, less mass, more acceleration.'
                : 'Every action force has an equal and opposite reaction force — that\'s what pushes both skaters apart.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'Newton\'s Third Law: for every action, there is an equal and opposite reaction. The forces are always equal — but since acceleration = force / mass, the lighter object moves away faster.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }
}

class _SkatersCanvas extends StatelessWidget {
  final double speedA;
  final double speedB;
  final bool pushed;
  const _SkatersCanvas({required this.speedA, required this.speedB, required this.pushed});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroDarkGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
      ),
      clipBehavior: Clip.hardEdge,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final centerX = constraints.maxWidth / 2;
          final travelA = pushed ? (speedA * 3.5).clamp(0, centerX - 40) : 0.0;
          final travelB = pushed ? (speedB * 3.5).clamp(0, centerX - 40) : 0.0;

          return Stack(
            children: [
              Positioned(
                left: centerX - 1,
                top: 0,
                bottom: 0,
                child: Container(width: 2, color: Colors.white.withValues(alpha: 0.12)),
              ),
              AnimatedPositioned(
                duration: const Duration(milliseconds: 700),
                curve: Curves.easeOut,
                left: centerX - 40 - travelA,
                top: 85,
                child: const Text('🔵⛸️', style: TextStyle(fontSize: 28)),
              ),
              AnimatedPositioned(
                duration: const Duration(milliseconds: 700),
                curve: Curves.easeOut,
                left: centerX + 12 + travelB,
                top: 85,
                child: const Text('⛸️🔴', style: TextStyle(fontSize: 28)),
              ),
              Positioned(
                bottom: 16,
                left: 0,
                right: 0,
                child: Text(
                  pushed ? 'Pushed apart with equal & opposite force' : 'Standing still, facing each other',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600, fontSize: 13),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
