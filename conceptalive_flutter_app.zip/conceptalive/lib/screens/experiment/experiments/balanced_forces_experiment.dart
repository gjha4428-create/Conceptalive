import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import 'experiment_widgets.dart';

/// Tug-of-war simulation for "Balanced and Unbalanced Forces".
/// Two teams pull with different forces; the knot in the rope drifts
/// toward whichever side pulls harder, or stays still if forces are equal
/// (balanced forces = no change in motion).
class BalancedForcesExperiment extends StatefulWidget {
  const BalancedForcesExperiment({super.key});

  @override
  State<BalancedForcesExperiment> createState() => _BalancedForcesExperimentState();
}

class _BalancedForcesExperimentState extends State<BalancedForcesExperiment> {
  double _leftForce = 50;
  double _rightForce = 50;

  double get _netForce => _rightForce - _leftForce; // positive => right wins
  bool get _isBalanced => _netForce.abs() < 3;

  @override
  Widget build(BuildContext context) {
    // Knot position from -1 (far left) to 1 (far right).
    final knotOffset = (_netForce / 100).clamp(-1.0, 1.0).toDouble();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ExperimentHintBanner(text: 'Pull each side and watch the rope!'),
        const SizedBox(height: 18),
        _TugOfWarCanvas(
          knotOffset: knotOffset,
          isBalanced: _isBalanced,
          leftForce: _leftForce,
          rightForce: _rightForce,
        ).animate().fadeIn(duration: 400.ms),
        const SizedBox(height: 24),
        Text('Variables', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        ExperimentSlider(
          label: 'Team A (Left)',
          unit: 'N',
          value: _leftForce,
          min: 0,
          max: 100,
          color: AppColors.secondary,
          emoji: '🔵',
          onChanged: (v) => setState(() => _leftForce = v),
        ),
        const SizedBox(height: 16),
        ExperimentSlider(
          label: 'Team B (Right)',
          unit: 'N',
          value: _rightForce,
          min: 0,
          max: 100,
          color: AppColors.error,
          emoji: '🔴',
          onChanged: (v) => setState(() => _rightForce = v),
        ),
        const SizedBox(height: 20),
        ExperimentFormulaCard(
          emoji: _isBalanced ? '⚖️' : '➡️',
          child: RichText(
            text: TextSpan(
              style: Theme.of(context).textTheme.bodyMedium,
              children: [
                const TextSpan(text: 'Net force = '),
                TextSpan(
                  text: '${_netForce.abs().toStringAsFixed(0)} N ',
                  style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary),
                ),
                TextSpan(
                  text: _isBalanced
                      ? '— forces are balanced, the rope stays still.'
                      : (_netForce > 0 ? 'toward Team B — unbalanced, rope moves right.' : 'toward Team A — unbalanced, rope moves left.'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'When two forces on an object are equal and opposite, they cancel out — the object stays at rest or keeps moving at constant speed. When they\'re unequal, the object accelerates toward the stronger force.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }
}

class _TugOfWarCanvas extends StatelessWidget {
  final double knotOffset; // -1..1
  final bool isBalanced;
  final double leftForce;
  final double rightForce;
  const _TugOfWarCanvas({
    required this.knotOffset,
    required this.isBalanced,
    required this.leftForce,
    required this.rightForce,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroDarkGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
      ),
      clipBehavior: Clip.hardEdge,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final centerX = constraints.maxWidth / 2;
          final travelRange = constraints.maxWidth / 2 - 76;
          final knotX = centerX + knotOffset * travelRange;
          const ropeY = 128.0;

          return Stack(
            children: [
              // Ground shadow strip
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(height: 26, color: Colors.black.withValues(alpha: 0.18)),
              ),
              // Faint center line (goal marker)
              Positioned(
                left: centerX - 1,
                top: 30,
                bottom: 26,
                child: Container(
                  width: 2,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.18),
                  ),
                ),
              ),
              // The rope itself, painted with a twisted texture and a slight sag
              Positioned.fill(
                child: CustomPaint(
                  painter: _RopePainter(knotX: knotX, ropeY: ropeY, width: constraints.maxWidth),
                ),
              ),
              // Left team (leans back harder as their force increases)
              Positioned(
                left: 14,
                top: ropeY - 76,
                child: _TeamGroup(force: leftForce, color: AppColors.secondary),
              ),
              // Right team
              Positioned(
                right: 14,
                top: ropeY - 76,
                child: Transform.flip(
                  flipX: true,
                  child: _TeamGroup(force: rightForce, color: AppColors.error),
                ),
              ),
              // Knot with a flag marker showing which side is winning
              AnimatedPositioned(
                duration: const Duration(milliseconds: 350),
                curve: Curves.easeOut,
                left: knotX - 12,
                top: ropeY - 10,
                child: _RopeKnot(isBalanced: isBalanced),
              ),
              Positioned(
                bottom: 6,
                left: 0,
                right: 0,
                child: Text(
                  isBalanced ? 'BALANCED — no motion' : 'UNBALANCED — rope moving',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: isBalanced ? AppColors.success : AppColors.accent,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// A small cluster of people straining against the rope. Leans back
/// further and shows more "effort" motion lines as force increases.
class _TeamGroup extends StatelessWidget {
  final double force; // 0..100
  final Color color;
  const _TeamGroup({required this.force, required this.color});

  @override
  Widget build(BuildContext context) {
    final lean = (force / 100).clamp(0.0, 1.0).toDouble() * 0.28; // radians, subtle backward lean
    const people = ['🧑', '🧑\u200d🦱'];

    return Transform.rotate(
      angle: -lean,
      alignment: Alignment.bottomCenter,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            width: 10,
            height: 10,
            margin: const EdgeInsets.only(bottom: 6, right: 2),
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          for (final p in people)
            Padding(
              padding: const EdgeInsets.only(right: 2),
              child: Text(p, style: const TextStyle(fontSize: 30)),
            ),
        ],
      ),
    );
  }
}

/// A small braided knot where the two rope ends meet, instead of a flat
/// circle marker.
class _RopeKnot extends StatelessWidget {
  final bool isBalanced;
  const _RopeKnot({required this.isBalanced});

  @override
  Widget build(BuildContext context) {
    final glow = isBalanced ? AppColors.success : AppColors.accent;
    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(colors: [Color(0xFFDDB892), Color(0xFF8B5E34)]),
        boxShadow: [BoxShadow(color: glow.withValues(alpha: 0.6), blurRadius: 12)],
        border: Border.all(color: glow, width: 2),
      ),
    );
  }
}

/// Paints a rope with a twisted texture and a natural sag, instead of a
/// flat solid bar.
class _RopePainter extends CustomPainter {
  final double knotX;
  final double ropeY;
  final double width;
  _RopePainter({required this.knotX, required this.ropeY, required this.width});

  @override
  void paint(Canvas canvas, Size size) {
    final left = Offset(24, ropeY - 6);
    final right = Offset(width - 24, ropeY - 6);
    final knot = Offset(knotX, ropeY);
    const sag = 10.0;

    final path = Path()
      ..moveTo(left.dx, left.dy)
      ..quadraticBezierTo(
        (left.dx + knot.dx) / 2,
        ropeY + sag,
        knot.dx,
        knot.dy,
      )
      ..quadraticBezierTo(
        (knot.dx + right.dx) / 2,
        ropeY + sag,
        right.dx,
        right.dy,
      );

    final ropePaint = Paint()
      ..color = const Color(0xFFC49A6C)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(path, ropePaint);

    // Twist texture: short diagonal strokes along the rope.
    final twistPaint = Paint()
      ..color = const Color(0xFF8B5E34).withValues(alpha: 0.6)
      ..strokeWidth = 2.2;

    final metrics = path.computeMetrics();
    for (final metric in metrics) {
      const spacing = 11.0;
      var distance = 4.0;
      while (distance < metric.length) {
        final tangent = metric.getTangentForOffset(distance);
        if (tangent != null) {
          final p = tangent.position;
          final dir = tangent.vector;
          final normal = Offset(-dir.dy, dir.dx);
          final len = normal.distance == 0 ? 1 : normal.distance;
          final n = Offset(normal.dx / len, normal.dy / len);
          canvas.drawLine(p - n * 4.5, p + n * 4.5, twistPaint);
        }
        distance += spacing;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RopePainter oldDelegate) =>
      oldDelegate.knotX != knotX || oldDelegate.ropeY != ropeY || oldDelegate.width != width;
}
