import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import 'experiment_widgets.dart';

/// Tug-of-war simulation for "Balanced and Unbalanced Forces".
/// Two teams pull with different forces; the knot in the rope drifts
/// toward whichever side pulls harder, or stays still if forces are equal
/// (balanced forces = no change in motion).
class BalancedForcesExperiment extends StatefulWidget {
  const BalancedForcesExperiment({super.key});

  @override
  State<BalancedForcesExperiment> createState() => _BalancedForcesExperimentState();
}

class _BalancedForcesExperimentState extends State<BalancedForcesExperiment> {
  double _leftForce = 50;
  double _rightForce = 50;

  double get _netForce => _rightForce - _leftForce; // positive => right wins
  bool get _isBalanced => _netForce.abs() < 3;

  @override
  Widget build(BuildContext context) {
    // Knot position from -1 (far left) to 1 (far right).
    final knotOffset = (_netForce / 100).clamp(-1.0, 1.0).toDouble();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ExperimentHintBanner(text: 'Pull each side and watch the rope!'),
        const SizedBox(height: 18),
        _TugOfWarCanvas(knotOffset: knotOffset, isBalanced: _isBalanced).animate().fadeIn(duration: 400.ms),
        const SizedBox(height: 24),
        Text('Variables', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        ExperimentSlider(
          label: 'Team A (Left)',
          unit: 'N',
          value: _leftForce,
          min: 0,
          max: 100,
          color: AppColors.secondary,
          emoji: '🔵',
          onChanged: (v) => setState(() => _leftForce = v),
        ),
        const SizedBox(height: 16),
        ExperimentSlider(
          label: 'Team B (Right)',
          unit: 'N',
          value: _rightForce,
          min: 0,
          max: 100,
          color: AppColors.error,
          emoji: '🔴',
          onChanged: (v) => setState(() => _rightForce = v),
        ),
        const SizedBox(height: 20),
        ExperimentFormulaCard(
          emoji: _isBalanced ? '⚖️' : '➡️',
          child: RichText(
            text: TextSpan(
              style: Theme.of(context).textTheme.bodyMedium,
              children: [
                const TextSpan(text: 'Net force = '),
                TextSpan(
                  text: '${_netForce.abs().toStringAsFixed(0)} N ',
                  style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary),
                ),
                TextSpan(
                  text: _isBalanced
                      ? '— forces are balanced, the rope stays still.'
                      : (_netForce > 0 ? 'toward Team B — unbalanced, rope moves right.' : 'toward Team A — unbalanced, rope moves left.'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'When two forces on an object are equal and opposite, they cancel out — the object stays at rest or keeps moving at constant speed. When they\'re unequal, the object accelerates toward the stronger force.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }
}

class _TugOfWarCanvas extends StatelessWidget {
  final double knotOffset; // -1..1
  final bool isBalanced;
  const _TugOfWarCanvas({required this.knotOffset, required this.isBalanced});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroDarkGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
      ),
      clipBehavior: Clip.hardEdge,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final centerX = constraints.maxWidth / 2;
          final travelRange = constraints.maxWidth / 2 - 60;
          final knotX = centerX + knotOffset * travelRange;

          return Stack(
            alignment: Alignment.center,
            children: [
              // Center line marker
              Positioned(
                left: centerX - 1,
                top: 0,
                bottom: 0,
                child: Container(width: 2, color: Colors.white.withValues(alpha: 0.15)),
              ),
              // Rope
              Positioned(
                top: 96,
                left: 30,
                right: 30,
                child: Container(height: 6, color: const Color(0xFFC49A6C)),
              ),
              // Left team
              const Positioned(left: 20, top: 60, child: Text('🔵🙂', style: TextStyle(fontSize: 26))),
              // Right team
              const Positioned(right: 20, top: 60, child: Text('🙂🔴', style: TextStyle(fontSize: 26))),
              // Knot
              AnimatedPositioned(
                duration: const Duration(milliseconds: 350),
                curve: Curves.easeOut,
                left: knotX - 14,
                top: 84,
                child: Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: isBalanced ? AppColors.success : AppColors.accent,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: (isBalanced ? AppColors.success : AppColors.accent).withValues(alpha: 0.5),
                        blurRadius: 14,
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 16,
                child: Text(
                  isBalanced ? 'BALANCED — no motion' : 'UNBALANCED — rope moving',
                  style: TextStyle(
                    color: isBalanced ? AppColors.success : AppColors.accent,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
