import 'package:flutter/material.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';

/// Small "tip" banner shown at the top of every experiment.
class ExperimentHintBanner extends StatelessWidget {
  final String text;
  const ExperimentHintBanner({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.accent.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.touch_app_rounded, size: 14, color: AppColors.accent),
          const SizedBox(width: 6),
          Flexible(
            child: Text(text,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(color: const Color(0xFFB8860B))),
          ),
        ],
      ),
    );
  }
}

/// Reusable labeled slider used across every experiment (force, mass,
/// friction, angle, velocity, etc.) — keeps every experiment visually
/// consistent while letting each one define its own variables.
class ExperimentSlider extends StatelessWidget {
  final String label;
  final String unit;
  final String emoji;
  final double value;
  final double min;
  final double max;
  final Color color;
  final ValueChanged<double> onChanged;

  const ExperimentSlider({
    super.key,
    required this.label,
    required this.unit,
    required this.emoji,
    required this.value,
    required this.min,
    required this.max,
    required this.color,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Text(label, style: Theme.of(context).textTheme.titleMedium),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: color.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(10)),
                child: Text('${value.toStringAsFixed(0)} $unit',
                    style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13)),
              ),
            ],
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: color,
              thumbColor: color,
              overlayColor: color.withValues(alpha: 0.15),
              inactiveTrackColor: color.withValues(alpha: 0.15),
            ),
            child: Slider(value: value, min: min, max: max, onChanged: onChanged),
          ),
        ],
      ),
    );
  }
}

/// A toggle button pair used by experiments that need a discrete choice
/// instead of (or alongside) a slider — e.g. surface type, collision type.
class ExperimentToggleRow extends StatelessWidget {
  final String label;
  final String emoji;
  final List<String> options;
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  const ExperimentToggleRow({
    super.key,
    required this.label,
    required this.emoji,
    required this.options,
    required this.selectedIndex,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Text(label, style: Theme.of(context).textTheme.titleMedium),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: List.generate(options.length, (i) {
              final selected = i == selectedIndex;
              return ChoiceChip(
                label: Text(options[i]),
                selected: selected,
                onSelected: (_) => onSelected(i),
                selectedColor: AppColors.primary.withValues(alpha: 0.2),
                labelStyle: TextStyle(
                  color: selected ? AppColors.primary : Theme.of(context).textTheme.bodyMedium?.color,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

/// The result/formula card shown under the simulation canvas of every
/// experiment (e.g. "F = m x a = ...").
class ExperimentFormulaCard extends StatelessWidget {
  final String emoji;
  final Widget child;
  const ExperimentFormulaCard({super.key, required this.emoji, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 10),
          Expanded(child: child),
        ],
      ),
    );
  }
}
