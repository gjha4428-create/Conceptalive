import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import 'experiment_widgets.dart';

/// F = m x a simulation — used for both the general "Force" topic
/// (push_pull_force) and "Newton's Second Law" (force_mass_acceleration),
/// since both are driven by the same relationship.
class ForceMassAccelerationExperiment extends StatefulWidget {
  const ForceMassAccelerationExperiment({super.key});

  @override
  State<ForceMassAccelerationExperiment> createState() => _ForceMassAccelerationExperimentState();
}

class _ForceMassAccelerationExperimentState extends State<ForceMassAccelerationExperiment> {
  double _force = 20;
  double _mass = 5;

  double get _acceleration => _mass == 0 ? 0 : _force / _mass;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ExperimentHintBanner(text: 'Move the sliders and watch it react live'),
        const SizedBox(height: 18),
        _SimulationCanvas(force: _force, mass: _mass, acceleration: _acceleration).animate().fadeIn(duration: 400.ms),
        const SizedBox(height: 24),
        Text('Variables', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        ExperimentSlider(
          label: 'Force',
          unit: 'N',
          value: _force,
          min: 0,
          max: 100,
          color: AppColors.primary,
          emoji: '💪',
          onChanged: (v) => setState(() => _force = v),
        ),
        const SizedBox(height: 16),
        ExperimentSlider(
          label: 'Mass',
          unit: 'kg',
          value: _mass,
          min: 1,
          max: 50,
          color: AppColors.secondary,
          emoji: '🧱',
          onChanged: (v) => setState(() => _mass = v),
        ),
        const SizedBox(height: 20),
        ExperimentFormulaCard(
          emoji: '🧮',
          child: RichText(
            text: TextSpan(
              style: Theme.of(context).textTheme.bodyMedium,
              children: [
                const TextSpan(text: 'F = m × a  →  a = F ÷ m  =  '),
                TextSpan(
                  text: '${_acceleration.toStringAsFixed(2)} m/s²',
                  style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'The same force produces less acceleration on a heavier object — that\'s Newton\'s Second Law.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }
}

class _SimulationCanvas extends StatelessWidget {
  final double force;
  final double mass;
  final double acceleration;

  const _SimulationCanvas({required this.force, required this.mass, required this.acceleration});

  @override
  Widget build(BuildContext context) {
    final travel = (acceleration.clamp(0, 20) / 20) * 200;

    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroDarkGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
      ),
      clipBehavior: Clip.hardEdge,
      child: Stack(
        children: [
          Positioned(
            bottom: 20,
            left: 20,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              curve: Curves.easeOut,
              transform: Matrix4.translationValues(travel, 0, 0),
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(color: AppColors.primary.withValues(alpha: 0.5), blurRadius: 16, offset: const Offset(0, 6)),
                ],
              ),
              alignment: Alignment.center,
              child: const Text('📦', style: TextStyle(fontSize: 24)),
            ),
          ),
          Positioned(
            left: 20,
            bottom: 90,
            child: Text('a = ${acceleration.toStringAsFixed(1)} m/s²',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(height: 20, color: Colors.white.withValues(alpha: 0.06)),
          ),
        ],
      ),
    );
  }
}
