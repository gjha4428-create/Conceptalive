import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import 'experiment_widgets.dart';

/// Newton's First Law (inertia) simulation. A block sits still until you
/// tap "Push". Lower friction (ice) makes it slide far before stopping;
/// higher friction (sand) stops it almost immediately — illustrating that
/// objects keep doing what they're doing unless a force (friction) acts
/// on them.
class InertiaExperiment extends StatefulWidget {
  const InertiaExperiment({super.key});

  @override
  State<InertiaExperiment> createState() => _InertiaExperimentState();
}

class _InertiaExperimentState extends State<InertiaExperiment> with SingleTickerProviderStateMixin {
  double _pushForce = 40;
  int _surfaceIndex = 1; // 0 ice, 1 wood, 2 sand
  bool _isSliding = false;
  double _travel = 0;

  static const _frictionForSurface = [0.05, 0.25, 0.7]; // ice, wood, sand
  static const _surfaceNames = ['Ice 🧊', 'Wood 🪵', 'Sand 🏖️'];

  void _push() {
    final friction = _frictionForSurface[_surfaceIndex];
    final distance = (_pushForce / (friction * 100 + 5)) * 60;
    setState(() {
      _isSliding = true;
      _travel = distance.clamp(0, 220);
    });
  }

  void _reset() => setState(() {
        _isSliding = false;
        _travel = 0;
      });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ExperimentHintBanner(text: 'Push the block and see how far it slides'),
        const SizedBox(height: 18),
        _InertiaCanvas(travel: _travel, isSliding: _isSliding).animate().fadeIn(duration: 400.ms),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _push,
                icon: const Icon(Icons.touch_app_rounded),
                label: const Text('Push'),
              ),
            ),
            const SizedBox(width: 12),
            OutlinedButton.icon(
              onPressed: _reset,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Reset'),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Text('Variables', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        ExperimentSlider(
          label: 'Push Force',
          unit: 'N',
          value: _pushForce,
          min: 5,
          max: 100,
          color: AppColors.primary,
          emoji: '💪',
          onChanged: (v) => setState(() => _pushForce = v),
        ),
        const SizedBox(height: 16),
        ExperimentToggleRow(
          label: 'Surface',
          emoji: '🧭',
          options: _surfaceNames,
          selectedIndex: _surfaceIndex,
          onSelected: (i) => setState(() => _surfaceIndex = i),
        ),
        const SizedBox(height: 20),
        ExperimentFormulaCard(
          emoji: '🛑',
          child: Text(
            _isSliding
                ? 'The block kept moving until friction from the ${_surfaceNames[_surfaceIndex].split(' ').first.toLowerCase()} slowed it to a stop.'
                : 'The block stays at rest — it takes a force (your push) to change that.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'Newton\'s First Law: an object at rest stays at rest, and an object in motion stays in motion at constant velocity, unless acted on by an unbalanced force (here, friction).',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }
}

class _InertiaCanvas extends StatelessWidget {
  final double travel;
  final bool isSliding;
  const _InertiaCanvas({required this.travel, required this.isSliding});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroDarkGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
      ),
      clipBehavior: Clip.hardEdge,
      child: Stack(
        children: [
          Positioned(
            bottom: 20,
            left: 20,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 900),
              curve: Curves.easeOutCubic,
              transform: Matrix4.translationValues(travel, 0, 0),
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(color: AppColors.primary.withValues(alpha: 0.5), blurRadius: 16, offset: const Offset(0, 6)),
                ],
              ),
              alignment: Alignment.center,
              child: const Text('📦', style: TextStyle(fontSize: 24)),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(height: 20, color: Colors.white.withValues(alpha: 0.06)),
          ),
        ],
      ),
    );
  }
}
