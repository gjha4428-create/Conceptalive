import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import 'experiment_widgets.dart';

/// Momentum simulation: a moving cart collides with a stationary cart and
/// they stick together (perfectly inelastic collision). Total momentum
/// before = total momentum after, so the combined cart's speed depends on
/// both masses — showing momentum = mass x velocity is conserved.
class MomentumExperiment extends StatefulWidget {
  const MomentumExperiment({super.key});

  @override
  State<MomentumExperiment> createState() => _MomentumExperimentState();
}

class _MomentumExperimentState extends State<MomentumExperiment> {
  double _massA = 10; // kg, moving cart
  double _velocityA = 8; // m/s
  double _massB = 10; // kg, stationary cart
  bool _collided = false;

  double get _momentumBefore => _massA * _velocityA;
  double get _velocityAfter => _momentumBefore / (_massA + _massB);

  void _launch() => setState(() => _collided = true);
  void _reset() => setState(() => _collided = false);

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const ExperimentHintBanner(text: 'Launch the cart and watch what happens on impact'),
        const SizedBox(height: 18),
        _CollisionCanvas(collided: _collided, velocityAfter: _velocityAfter).animate().fadeIn(duration: 400.ms),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _launch,
                icon: const Icon(Icons.arrow_forward_rounded),
                label: const Text('Launch'),
              ),
            ),
            const SizedBox(width: 12),
            OutlinedButton.icon(
              onPressed: _reset,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Reset'),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Text('Variables', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        ExperimentSlider(
          label: 'Cart A mass (moving)',
          unit: 'kg',
          value: _massA,
          min: 1,
          max: 30,
          color: AppColors.primary,
          emoji: '🟪',
          onChanged: (v) => setState(() {
            _massA = v;
            _collided = false;
          }),
        ),
        const SizedBox(height: 16),
        ExperimentSlider(
          label: 'Cart A velocity',
          unit: 'm/s',
          value: _velocityA,
          min: 1,
          max: 20,
          color: AppColors.accent,
          emoji: '🚀',
          onChanged: (v) => setState(() {
            _velocityA = v;
            _collided = false;
          }),
        ),
        const SizedBox(height: 16),
        ExperimentSlider(
          label: 'Cart B mass (still)',
          unit: 'kg',
          value: _massB,
          min: 1,
          max: 30,
          color: AppColors.secondary,
          emoji: '🟩',
          onChanged: (v) => setState(() {
            _massB = v;
            _collided = false;
          }),
        ),
        const SizedBox(height: 20),
        ExperimentFormulaCard(
          emoji: '💥',
          child: RichText(
            text: TextSpan(
              style: Theme.of(context).textTheme.bodyMedium,
              children: [
                const TextSpan(text: 'p = m × v  →  momentum before = '),
                TextSpan(
                  text: '${_momentumBefore.toStringAsFixed(0)} kg·m/s',
                  style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary),
                ),
                if (_collided) ...[
                  const TextSpan(text: '\nAfter sticking together, combined speed = '),
                  TextSpan(
                    text: '${_velocityAfter.toStringAsFixed(2)} m/s',
                    style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.secondary),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            'Momentum is conserved in a collision: total momentum before equals total momentum after. A heavier stationary cart "absorbs" more, slowing the combined result down more.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }
}

class _CollisionCanvas extends StatelessWidget {
  final bool collided;
  final double velocityAfter;
  const _CollisionCanvas({required this.collided, required this.velocityAfter});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroDarkGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
      ),
      clipBehavior: Clip.hardEdge,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final combinedTravel = collided ? (velocityAfter * 6).clamp(0, constraints.maxWidth - 140) : 0.0;

          return Stack(
            children: [
              if (!collided) ...[
                const Positioned(left: 24, top: 85, child: Text('🟪💨', style: TextStyle(fontSize: 28))),
                const Positioned(right: 40, top: 85, child: Text('🟩', style: TextStyle(fontSize: 28))),
              ] else
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 700),
                  curve: Curves.easeOut,
                  left: 24 + combinedTravel,
                  top: 85,
                  child: const Text('🟪🟩', style: TextStyle(fontSize: 28)),
                ),
              Positioned(
                bottom: 16,
                left: 0,
                right: 0,
                child: Text(
                  collided ? 'Collided and stuck together' : 'Cart A approaching Cart B',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600, fontSize: 13),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
