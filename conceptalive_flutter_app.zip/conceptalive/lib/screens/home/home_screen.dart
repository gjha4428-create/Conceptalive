import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/topic_model.dart';
import '../../providers/content_provider.dart';
import '../../providers/progress_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../utils/constants.dart';
import '../../routes/app_routes.dart';
import '../../widgets/common/section_header.dart';
import '../../widgets/common/glass_card.dart';
import '../../widgets/home/streak_widget.dart';
import '../../widgets/home/subject_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final content = context.read<ContentProvider>();
      final progress = context.read<ProgressProvider>();
      if (content.subjects.isEmpty) content.loadSubjects();
      if (progress.progress == null) progress.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final content = context.watch<ContentProvider>();
    final progressProv = context.watch<ProgressProvider>();
    final progress = progressProv.progress;
    final hour = DateTime.now().hour;
    final greeting = hour < 12 ? 'Good morning' : (hour < 17 ? 'Good afternoon' : 'Good evening');

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            await context.read<ContentProvider>().loadSubjects();
            await context.read<ProgressProvider>().load();
          },
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
                AppConstants.screenPaddingH, 12, AppConstants.screenPaddingH, 100),
            children: [
              // Greeting + avatar row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(greeting, style: Theme.of(context).textTheme.bodyMedium),
                      Text(progress?.userName ?? 'Explorer 👋',
                          style: Theme.of(context).textTheme.displaySmall),
                    ],
                  ),
                  Container(
                    width: 48,
                    height: 48,
                    decoration: const BoxDecoration(
                      gradient: AppColors.primaryGradient,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.person_rounded, color: Colors.white),
                  ),
                ],
              ).animate().fadeIn(duration: 400.ms),
              const SizedBox(height: 18),

              // Search bar (placeholder — future: AI-powered concept search)
              TextField(
                readOnly: true,
                onTap: () {},
                decoration: InputDecoration(
                  hintText: 'Search topics, e.g. "Newton\'s Laws"',
                  prefixIcon: const Icon(Icons.search_rounded),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppTheme.radiusMd)),
                ),
              ).animate().fadeIn(delay: 100.ms, duration: 400.ms),
              const SizedBox(height: 20),

              // Streak + XP
              if (progress != null)
                StreakWidget(streakDays: progress.currentStreakDays, totalXp: progress.totalXp)
                    .animate()
                    .fadeIn(delay: 150.ms, duration: 400.ms),
              const SizedBox(height: 26),

              // Continue Learning
              const SectionHeader(title: 'Continue Learning'),
              const SizedBox(height: 12),
              _ContinueLearningCard(
                onTap: () => context.push(AppRoutes.topicPath('balanced-unbalanced-forces')),
              ).animate().fadeIn(delay: 200.ms, duration: 400.ms),
              const SizedBox(height: 28),

              // Subjects
              const SectionHeader(title: 'Subjects'),
              const SizedBox(height: 12),
              if (content.isLoadingSubjects)
                const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
              else
                Row(
                  children: [
                    for (int i = 0; i < content.subjects.length; i++) ...[
                      Expanded(
                        child: SubjectCard(
                          subject: content.subjects[i],
                          onTap: () {
                            if (content.subjects[i].id == 'science') {
                              context.push(AppRoutes.science);
                            }
                          },
                        ),
                      ),
                      if (i != content.subjects.length - 1) const SizedBox(width: 14),
                    ],
                  ],
                ).animate().fadeIn(delay: 250.ms, duration: 400.ms),
              const SizedBox(height: 28),

              // Recently viewed
              const SectionHeader(title: 'Recently Viewed'),
              const SizedBox(height: 12),
              SizedBox(
                height: 96,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _RecentChip(emoji: '👋', title: 'Force', onTap: () => context.push(AppRoutes.topicPath('force'))),
                    _RecentChip(
                        emoji: '⚖️',
                        title: 'Balanced Forces',
                        onTap: () => context.push(AppRoutes.topicPath('balanced-unbalanced-forces'))),
                  ],
                ),
              ).animate().fadeIn(delay: 300.ms, duration: 400.ms),
              const SizedBox(height: 28),

              // Achievements preview
              const SectionHeader(title: 'Achievements'),
              const SizedBox(height: 12),
              if (progress != null)
                SizedBox(
                  height: 100,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: progress.achievements.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (context, i) {
                      final a = progress.achievements[i];
                      return Container(
                        width: 92,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: a.isUnlocked
                              ? AppColors.accent.withValues(alpha: 0.14)
                              : Theme.of(context).cardTheme.color,
                          borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                          border: Border.all(color: Theme.of(context).dividerColor),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Opacity(
                              opacity: a.isUnlocked ? 1 : 0.3,
                              child: Text(a.emoji, style: const TextStyle(fontSize: 26)),
                            ),
                            const SizedBox(height: 6),
                            Text(a.title,
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10)),
                          ],
                        ),
                      );
                    },
                  ),
                ).animate().fadeIn(delay: 350.ms, duration: 400.ms),
            ],
          ),
        ),
      ),
    );
  }
}

class _ContinueLearningCard extends StatelessWidget {
  final VoidCallback onTap;
  const _ContinueLearningCard({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GradientCard(
      gradient: AppColors.scienceGradient,
      onTap: onTap,
      child: Row(
        children: [
          Text('⚖️', style: const TextStyle(fontSize: 40)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Balanced and Unbalanced Forces',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)),
                const SizedBox(height: 6),
                Text('Force and Laws of Motion • 40% complete',
                    style: TextStyle(color: Colors.white.withValues(alpha: 0.85), fontSize: 12)),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: 0.4,
                    minHeight: 6,
                    backgroundColor: Colors.white.withValues(alpha: 0.25),
                    valueColor: const AlwaysStoppedAnimation(Colors.white),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          const Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 34),
        ],
      ),
    );
  }
}

class _RecentChip extends StatelessWidget {
  final String emoji;
  final String title;
  final VoidCallback onTap;

  const _RecentChip({required this.emoji, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12),
      child: Material(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppTheme.radiusMd),
          onTap: onTap,
          child: Container(
            width: 110,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppTheme.radiusMd),
              border: Border.all(color: Theme.of(context).dividerColor),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(emoji, style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 8),
                Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
