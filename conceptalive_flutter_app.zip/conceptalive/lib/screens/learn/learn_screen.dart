import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import '../../models/topic_model.dart';
import '../../providers/content_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../utils/constants.dart';
import '../../routes/app_routes.dart';
import '../../widgets/common/app_button.dart';

/// The "Learn" stage — shows a Claude-generated, grade-appropriate
/// explanation. Architecture note: this screen never talks to
/// ContentService's implementation directly, only its interface, so
/// switching from LocalContentService to a live Claude API client is a
/// one-line change in main.dart's dependency setup.
class LearnScreen extends StatefulWidget {
  final String topicId;
  const LearnScreen({super.key, required this.topicId});

  @override
  State<LearnScreen> createState() => _LearnScreenState();
}

class _LearnScreenState extends State<LearnScreen> {
  TopicModel? _topic;
  String? _explanation;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final content = context.read<ContentProvider>();
    final topic = await content.topicById(widget.topicId);
    if (topic == null) {
      setState(() => _loading = false);
      return;
    }
    final explanation = await content.learnExplanation(topic.learnPromptKey);
    if (!mounted) return;
    setState(() {
      _topic = topic;
      _explanation = explanation;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_topic?.title ?? 'Learn')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
              AppConstants.screenPaddingH, 0, AppConstants.screenPaddingH, 24),
          child: _loading ? _buildLoading(context) : _buildContent(context),
        ),
      ),
    );
  }

  Widget _buildLoading(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return ListView(
      children: [
        const SizedBox(height: 8),
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  const SizedBox(
                    width: 12, height: 12,
                    child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary),
                  ),
                  const SizedBox(width: 8),
                  Text('Claude AI is thinking…',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.primary)),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Shimmer.fromColors(
          baseColor: isDark ? Colors.white10 : Colors.black12,
          highlightColor: isDark ? Colors.white24 : Colors.black26,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: List.generate(
              6,
              (i) => Container(
                margin: const EdgeInsets.only(bottom: 12),
                height: 16,
                width: i == 5 ? 180 : double.infinity,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(6)),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildContent(BuildContext context) {
    final topic = _topic!;
    return ListView(
      children: [
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: AppColors.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.auto_awesome_rounded, size: 14, color: AppColors.primary),
              const SizedBox(width: 6),
              Text('Explained by Claude AI • ${AppConstants.defaultGradeLevel} level',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.primary)),
            ],
          ),
        ).animate().fadeIn(duration: 300.ms),
        const SizedBox(height: 20),
        Center(child: Text(topic.heroEmoji, style: const TextStyle(fontSize: 56)))
            .animate().scale(duration: 400.ms, curve: Curves.easeOutBack),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Theme.of(context).cardTheme.color,
            borderRadius: BorderRadius.circular(AppTheme.radiusLg),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
          child: Text(
            _explanation ?? '',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.6),
          ),
        ).animate().fadeIn(delay: 150.ms, duration: 400.ms).moveY(begin: 10, end: 0),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.info.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(AppTheme.radiusMd),
          ),
          child: Row(
            children: [
              const Text('💡', style: TextStyle(fontSize: 18)),
              const SizedBox(width: 10),
              Expanded(
                child: Text('Tip: try the interactive experiment next to see this concept in action!',
                    style: Theme.of(context).textTheme.bodySmall),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        PrimaryButton(
          label: 'Watch the Animation',
          icon: Icons.play_circle_fill_rounded,
          onTap: () => context.push(AppRoutes.animationPath(topic.id)),
        ),
      ],
    );
  }
}
