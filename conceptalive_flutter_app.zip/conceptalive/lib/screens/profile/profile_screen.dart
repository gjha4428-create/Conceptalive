import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../providers/progress_provider.dart';
import '../../providers/theme_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../utils/constants.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _notifications = true;
  String _language = 'English';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final p = context.read<ProgressProvider>();
      if (p.progress == null) p.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProv = context.watch<ThemeProvider>();
    final progress = context.watch<ProgressProvider>().progress;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
              AppConstants.screenPaddingH, 12, AppConstants.screenPaddingH, 60),
          children: [
            Text('Profile', style: Theme.of(context).textTheme.displaySmall).animate().fadeIn(duration: 300.ms),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(AppTheme.radiusLg),
              ),
              child: Row(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), shape: BoxShape.circle),
                    child: const Icon(Icons.person_rounded, color: Colors.white, size: 32),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(progress?.userName ?? 'Explorer',
                            style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        Text('Level ${progress?.level ?? 1} • ${progress?.totalXp ?? 0} XP',
                            style: TextStyle(color: Colors.white.withValues(alpha: 0.85))),
                      ],
                    ),
                  ),
                  const Icon(Icons.edit_rounded, color: Colors.white, size: 18),
                ],
              ),
            ).animate().fadeIn(delay: 100.ms, duration: 300.ms),
            const SizedBox(height: 28),

            Text('Settings', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),
            _SettingsGroup(children: [
              _SettingsSwitchTile(
                icon: Icons.dark_mode_rounded,
                title: 'Dark Mode',
                value: themeProv.isDark,
                onChanged: (v) => themeProv.toggle(v),
              ),
              _SettingsTile(
                icon: Icons.language_rounded,
                title: 'Language',
                trailing: _language,
                onTap: () async {
                  final selected = await showModalBottomSheet<String>(
                    context: context,
                    builder: (context) => _LanguagePicker(current: _language),
                  );
                  if (selected != null) setState(() => _language = selected);
                },
              ),
              _SettingsSwitchTile(
                icon: Icons.notifications_rounded,
                title: 'Notifications',
                value: _notifications,
                onChanged: (v) => setState(() => _notifications = v),
              ),
            ]).animate().fadeIn(delay: 150.ms, duration: 300.ms),

            const SizedBox(height: 24),
            Text('Learning', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),
            _SettingsGroup(children: [
              _SettingsTile(icon: Icons.school_rounded, title: 'Grade Level', trailing: AppConstants.defaultGradeLevel, onTap: () {}),
              _SettingsTile(icon: Icons.emoji_events_rounded, title: 'Achievements', trailing: '${progress?.achievements.where((a) => a.isUnlocked).length ?? 0} unlocked', onTap: () {}),
              _SettingsTile(icon: Icons.download_rounded, title: 'Offline Mode', trailing: 'Coming soon', onTap: () {}),
            ]).animate().fadeIn(delay: 200.ms, duration: 300.ms),

            const SizedBox(height: 24),
            Text('About', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),
            _SettingsGroup(children: [
              _SettingsTile(icon: Icons.info_outline_rounded, title: 'App Version', trailing: '0.1.0', onTap: () {}),
              _SettingsTile(icon: Icons.privacy_tip_outlined, title: 'Privacy Policy', trailing: '', onTap: () {}),
              _SettingsTile(icon: Icons.logout_rounded, title: 'Sign Out', trailing: '', onTap: () {}, isDestructive: true),
            ]).animate().fadeIn(delay: 250.ms, duration: 300.ms),
          ],
        ),
      ),
    );
  }
}

class _SettingsGroup extends StatelessWidget {
  final List<Widget> children;
  const _SettingsGroup({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        children: [
          for (int i = 0; i < children.length; i++) ...[
            children[i],
            if (i != children.length - 1) Divider(height: 1, color: Theme.of(context).dividerColor),
          ],
        ],
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String trailing;
  final VoidCallback onTap;
  final bool isDestructive;

  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.trailing,
    required this.onTap,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = isDestructive ? AppColors.error : null;
    return ListTile(
      leading: Icon(icon, color: color ?? AppColors.primary),
      title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (trailing.isNotEmpty) Text(trailing, style: Theme.of(context).textTheme.bodySmall),
          if (!isDestructive) const SizedBox(width: 4),
          if (!isDestructive) const Icon(Icons.chevron_right_rounded, size: 18),
        ],
      ),
      onTap: onTap,
    );
  }
}

class _SettingsSwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SettingsSwitchTile({required this.icon, required this.title, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      secondary: Icon(icon, color: AppColors.primary),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      value: value,
      onChanged: onChanged,
      activeTrackColor: AppColors.primary,
    );
  }
}

class _LanguagePicker extends StatelessWidget {
  final String current;
  const _LanguagePicker({required this.current});

  @override
  Widget build(BuildContext context) {
    const languages = ['English', 'Hindi', 'Spanish', 'French'];
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 12),
          for (final lang in languages)
            ListTile(
              title: Text(lang),
              trailing: lang == current ? const Icon(Icons.check_rounded, color: AppColors.primary) : null,
              onTap: () => Navigator.pop(context, lang),
            ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
