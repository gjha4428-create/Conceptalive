import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../../providers/progress_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../utils/constants.dart';
import '../../widgets/common/section_header.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final p = context.read<ProgressProvider>();
      if (p.progress == null) p.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final progressProv = context.watch<ProgressProvider>();
    final progress = progressProv.progress;

    return Scaffold(
      body: SafeArea(
        child: progress == null
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.fromLTRB(
                    AppConstants.screenPaddingH, 12, AppConstants.screenPaddingH, 100),
                children: [
                  Text('Your Progress', style: Theme.of(context).textTheme.displaySmall)
                      .animate().fadeIn(duration: 300.ms),
                  const SizedBox(height: 20),

                  Row(
                    children: [
                      Expanded(
                        child: _MetricCard(
                          emoji: '🔥',
                          value: '${progress.currentStreakDays}',
                          label: 'Day streak',
                          gradient: AppColors.streakGradient,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _MetricCard(
                          emoji: '⭐',
                          value: '${progress.totalXp}',
                          label: 'Total XP',
                          gradient: const LinearGradient(colors: [Color(0xFF54A0FF), Color(0xFF6C5CE7)]),
                        ),
                      ),
                    ],
                  ).animate().fadeIn(delay: 100.ms, duration: 300.ms),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _MetricCard(
                          emoji: '🎓',
                          value: 'Lvl ${progress.level}',
                          label: 'Current level',
                          gradient: AppColors.scienceGradient,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _MetricCard(
                          emoji: '🏆',
                          value: '${progress.achievements.where((a) => a.isUnlocked).length}',
                          label: 'Badges earned',
                          gradient: AppColors.mathGradient,
                        ),
                      ),
                    ],
                  ).animate().fadeIn(delay: 150.ms, duration: 300.ms),
                  const SizedBox(height: 28),

                  const SectionHeader(title: 'Weekly Activity'),
                  const SizedBox(height: 14),
                  Container(
                    height: 180,
                    padding: const EdgeInsets.fromLTRB(12, 20, 20, 8),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardTheme.color,
                      borderRadius: BorderRadius.circular(AppTheme.radiusLg),
                      border: Border.all(color: Theme.of(context).dividerColor),
                    ),
                    child: BarChart(
                      BarChartData(
                        alignment: BarChartAlignment.spaceAround,
                        gridData: const FlGridData(show: false),
                        borderData: FlBorderData(show: false),
                        titlesData: FlTitlesData(
                          leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              getTitlesWidget: (v, meta) {
                                const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
                                return Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: Text(days[v.toInt() % 7], style: Theme.of(context).textTheme.bodySmall),
                                );
                              },
                            ),
                          ),
                        ),
                        barGroups: [18, 32, 12, 40, 25, 8, 15]
                            .asMap()
                            .entries
                            .map((e) => BarChartGroupData(x: e.key, barRods: [
                                  BarChartRodData(
                                    toY: e.value.toDouble(),
                                    color: AppColors.primary,
                                    width: 16,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                ]))
                            .toList(),
                      ),
                    ),
                  ).animate().fadeIn(delay: 200.ms, duration: 300.ms),
                  const SizedBox(height: 28),

                  const SectionHeader(title: 'Chapters'),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardTheme.color,
                      borderRadius: BorderRadius.circular(AppTheme.radiusLg),
                      border: Border.all(color: Theme.of(context).dividerColor),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 52, height: 52,
                          decoration: BoxDecoration(
                            gradient: AppColors.scienceGradient,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          alignment: Alignment.center,
                          child: const Text('🚀', style: TextStyle(fontSize: 24)),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Force and Laws of Motion', style: Theme.of(context).textTheme.titleMedium),
                              const SizedBox(height: 6),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: LinearProgressIndicator(
                                  value: progress.chapterProgress['force-and-laws-of-motion'] ?? 0,
                                  minHeight: 7,
                                  backgroundColor: Theme.of(context).dividerColor,
                                  valueColor: const AlwaysStoppedAnimation(AppColors.secondary),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          '${((progress.chapterProgress['force-and-laws-of-motion'] ?? 0) * 100).round()}%',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ],
                    ),
                  ).animate().fadeIn(delay: 250.ms, duration: 300.ms),
                  const SizedBox(height: 28),

                  const SectionHeader(title: 'Achievements'),
                  const SizedBox(height: 12),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: progress.achievements.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 2.6,
                    ),
                    itemBuilder: (context, i) {
                      final a = progress.achievements[i];
                      return Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: a.isUnlocked
                              ? AppColors.accent.withValues(alpha: 0.12)
                              : Theme.of(context).cardTheme.color,
                          borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                          border: Border.all(color: Theme.of(context).dividerColor),
                        ),
                        child: Row(
                          children: [
                            Opacity(opacity: a.isUnlocked ? 1 : 0.3, child: Text(a.emoji, style: const TextStyle(fontSize: 22))),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(a.title, style: Theme.of(context).textTheme.titleSmall, maxLines: 1, overflow: TextOverflow.ellipsis),
                                  Text(a.description, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10), maxLines: 1, overflow: TextOverflow.ellipsis),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ).animate().fadeIn(delay: 300.ms, duration: 300.ms),
                ],
              ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String emoji;
  final String value;
  final String label;
  final Gradient gradient;

  const _MetricCard({required this.emoji, required this.value, required this.label, required this.gradient});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(gradient: gradient, borderRadius: BorderRadius.circular(AppTheme.radiusLg)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 10),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20)),
          Text(label, style: TextStyle(color: Colors.white.withValues(alpha: 0.85), fontSize: 12)),
        ],
      ),
    );
  }
}
