import 'package:flutter/material.dart';
import 'package:confetti/confetti.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/quiz_model.dart';
import '../../providers/progress_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../routes/app_routes.dart';

class QuizResultScreen extends StatefulWidget {
  final QuizAttemptResult result;
  const QuizResultScreen({super.key, required this.result});

  @override
  State<QuizResultScreen> createState() => _QuizResultScreenState();
}

class _QuizResultScreenState extends State<QuizResultScreen> {
  late ConfettiController _confetti;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 2));
    final passed = widget.result.scorePercent >= 60;
    if (passed) {
      _confetti.play();
      final xp = (widget.result.correctCount * 15);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<ProgressProvider>().addXp(xp);
      });
    }
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.result;
    final passed = r.scorePercent >= 60;
    final xpEarned = r.correctCount * 15;

    return Scaffold(
      body: SafeArea(
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      gradient: passed ? AppColors.scienceGradient : AppColors.mathGradient,
                      shape: BoxShape.circle,
                    ),
                    alignment: Alignment.center,
                    child: Text(passed ? '🏆' : '💪', style: const TextStyle(fontSize: 56)),
                  ).animate().scale(duration: 500.ms, curve: Curves.elasticOut),
                  const SizedBox(height: 24),
                  Text(
                    passed ? 'Great job!' : 'Nice try!',
                    style: Theme.of(context).textTheme.displayMedium,
                  ).animate().fadeIn(delay: 200.ms),
                  const SizedBox(height: 8),
                  Text(
                    passed
                        ? 'You\'ve mastered the key ideas here.'
                        : 'Review the concept and give it another shot.',
                    style: Theme.of(context).textTheme.bodyLarge,
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(delay: 300.ms),
                  const SizedBox(height: 32),
                  Row(
                    children: [
                      Expanded(
                        child: _StatCard(
                          label: 'Score',
                          value: '${r.correctCount}/${r.totalCount}',
                          emoji: '🎯',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _StatCard(
                          label: 'Accuracy',
                          value: '${r.scorePercent.round()}%',
                          emoji: '📊',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _StatCard(
                          label: 'XP earned',
                          value: '+$xpEarned',
                          emoji: '⭐',
                        ),
                      ),
                    ],
                  ).animate().fadeIn(delay: 400.ms).moveY(begin: 12, end: 0),
                  const SizedBox(height: 40),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => context.go(AppRoutes.home),
                      child: const Text('Continue Learning'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: () => context.pop(),
                    child: const Text('Review answers'),
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: ConfettiWidget(
                confettiController: _confetti,
                blastDirection: 1.57,
                numberOfParticles: 24,
                maxBlastForce: 20,
                minBlastForce: 8,
                emissionFrequency: 0.06,
                gravity: 0.3,
                colors: const [AppColors.primary, AppColors.secondary, AppColors.accent, AppColors.xpGold],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final String emoji;
  const _StatCard({required this.label, required this.value, required this.emoji});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(height: 8),
          Text(value, style: Theme.of(context).textTheme.titleLarge),
          Text(label, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}
