import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/quiz_model.dart';
import '../../models/topic_model.dart';
import '../../providers/content_provider.dart';
import '../../services/quiz_service.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../routes/app_routes.dart';
import '../../widgets/quiz/mcq_option.dart';

/// The "Practice" stage — an adaptive MCQ quiz engine. Architecture is
/// generic: it renders whatever QuizModel QuizService returns, so a future
/// Claude-generated, mastery-adaptive quiz plugs in without UI changes.
class QuizScreen extends StatefulWidget {
  final String topicId;
  const QuizScreen({super.key, required this.topicId});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  TopicModel? _topic;
  QuizModel? _quiz;
  int _index = 0;
  int? _selected;
  bool _answered = false;
  int _correctCount = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final content = context.read<ContentProvider>();
    final quizService = context.read<QuizService>();
    final topic = await content.topicById(widget.topicId);
    if (topic == null) return;
    final quiz = await quizService.generateQuiz(quizPromptKey: topic.quizPromptKey);
    if (!mounted) return;
    setState(() {
      _topic = topic;
      _quiz = quiz;
    });
  }

  void _select(int i) {
    if (_answered) return;
    final q = _quiz!.questions[_index];
    setState(() {
      _selected = i;
      _answered = true;
      if (i == q.correctIndex) _correctCount++;
    });
  }

  void _next() {
    final total = _quiz!.questions.length;
    if (_index < total - 1) {
      setState(() {
        _index++;
        _selected = null;
        _answered = false;
      });
    } else {
      context.pushReplacement(
        AppRoutes.quizResult,
        extra: QuizAttemptResult(
          quizId: _quiz!.id,
          correctCount: _correctCount,
          totalCount: total,
          completedAt: DateTime.now(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_quiz == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Quiz')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final q = _quiz!.questions[_index];
    final total = _quiz!.questions.length;
    final labels = ['A', 'B', 'C', 'D', 'E'];

    return Scaffold(
      appBar: AppBar(title: Text(_topic?.title ?? 'Quiz')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: (_index + 1) / total,
                        minHeight: 8,
                        backgroundColor: Theme.of(context).dividerColor,
                        valueColor: const AlwaysStoppedAnimation(AppColors.primary),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text('${_index + 1}/$total', style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
              const SizedBox(height: 24),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(q.question, style: Theme.of(context).textTheme.displaySmall)
                          .animate(key: ValueKey(q.id))
                          .fadeIn(duration: 300.ms)
                          .moveY(begin: 10, end: 0),
                      const SizedBox(height: 22),
                      for (int i = 0; i < q.options.length; i++)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: McqOption(
                            label: labels[i],
                            text: q.options[i],
                            state: !_answered
                                ? McqOptionState.normal
                                : (i == q.correctIndex
                                    ? McqOptionState.correct
                                    : (i == _selected ? McqOptionState.incorrect : McqOptionState.normal)),
                            onTap: () => _select(i),
                          ),
                        ),
                      if (_answered)
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: (_selected == q.correctIndex ? AppColors.success : AppColors.info)
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(_selected == q.correctIndex ? '🎉' : '💡', style: const TextStyle(fontSize: 18)),
                              const SizedBox(width: 10),
                              Expanded(child: Text(q.explanation, style: Theme.of(context).textTheme.bodyMedium)),
                            ],
                          ),
                        ).animate().fadeIn(duration: 300.ms),
                    ],
                  ),
                ),
              ),
              if (_answered)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _next,
                    child: Text(_index < total - 1 ? 'Next Question' : 'See Results'),
                  ),
                ).animate().fadeIn(duration: 250.ms),
            ],
          ),
        ),
      ),
    );
  }
}
