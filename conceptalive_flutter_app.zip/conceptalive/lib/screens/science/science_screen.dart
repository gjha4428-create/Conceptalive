import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/chapter_model.dart';
import '../../providers/content_provider.dart';
import '../../utils/constants.dart';
import '../../routes/app_routes.dart';
import '../../widgets/chapter/chapter_card.dart';

/// Displays all chapters for the Science subject. [embedded] controls
/// whether this shows its own AppBar (used standalone) or is nested inside
/// the RootShell "Explore" tab.
class ScienceScreen extends StatefulWidget {
  final bool embedded;
  const ScienceScreen({super.key, this.embedded = false});

  @override
  State<ScienceScreen> createState() => _ScienceScreenState();
}

class _ScienceScreenState extends State<ScienceScreen> {
  late Future<List<ChapterModel>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<ContentProvider>().chaptersFor('science');
  }

  @override
  Widget build(BuildContext context) {
    final body = SafeArea(
      child: FutureBuilder<List<ChapterModel>>(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final chapters = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.fromLTRB(
                AppConstants.screenPaddingH, 12, AppConstants.screenPaddingH, 40),
            children: [
              if (widget.embedded) ...[
                Text('Explore', style: Theme.of(context).textTheme.displaySmall),
                const SizedBox(height: 4),
                Text('Science', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 18),
              ],
              Text('${chapters.length} chapter${chapters.length == 1 ? '' : 's'} available',
                  style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 12),
              for (int i = 0; i < chapters.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: ChapterCard(
                    chapter: chapters[i],
                    onTap: () => context.push(AppRoutes.chapterPath(chapters[i].id)),
                  ).animate().fadeIn(delay: (80 * i).ms, duration: 400.ms).moveY(begin: 16, end: 0),
                ),
              const SizedBox(height: 20),
              _ComingSoonCard(subject: 'Science'),
            ],
          );
        },
      ),
    );

    if (widget.embedded) return Scaffold(body: body);
    return Scaffold(appBar: AppBar(title: const Text('Science')), body: body);
  }
}

class _ComingSoonCard extends StatelessWidget {
  final String subject;
  const _ComingSoonCard({required this.subject});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor, style: BorderStyle.solid),
      ),
      child: Column(
        children: [
          const Text('✨', style: TextStyle(fontSize: 30)),
          const SizedBox(height: 8),
          Text('More $subject chapters coming soon', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text('New chapters unlock automatically as they\'re added — no update needed.',
              textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}
