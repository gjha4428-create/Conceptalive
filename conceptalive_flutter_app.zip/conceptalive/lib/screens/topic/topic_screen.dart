import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/topic_model.dart';
import '../../providers/content_provider.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../utils/extensions.dart';
import '../../routes/app_routes.dart';
import '../../widgets/common/app_button.dart';

/// The hub screen for a single topic — presents the 5-stage learning
/// journey (Learn / Watch / Experiment / Quiz, with Master reflected via
/// progress) as four large, equally-weighted action buttons.
class TopicScreen extends StatefulWidget {
  final String topicId;
  const TopicScreen({super.key, required this.topicId});

  @override
  State<TopicScreen> createState() => _TopicScreenState();
}

class _TopicScreenState extends State<TopicScreen> {
  late Future<TopicModel?> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<ContentProvider>().topicById(widget.topicId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('')),
      body: FutureBuilder<TopicModel?>(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final topic = snapshot.data;
          if (topic == null) return const Center(child: Text('Topic not found'));

          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
            children: [
              // Hero
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 30),
                decoration: BoxDecoration(
                  gradient: AppColors.scienceGradient,
                  borderRadius: BorderRadius.circular(AppTheme.radiusXl),
                ),
                child: Column(
                  children: [
                    Text(topic.heroEmoji, style: const TextStyle(fontSize: 64))
                        .animate(onPlay: (c) => c.repeat(reverse: true))
                        .moveY(duration: 1400.ms, begin: -4, end: 4),
                    const SizedBox(height: 14),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(topic.title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 400.ms),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(topic.shortDescription,
                    textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.timer_outlined, size: 14, color: Theme.of(context).textTheme.bodySmall?.color),
                  const SizedBox(width: 4),
                  Text(topic.estimatedMinutes.asMinutesLabel, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(width: 14),
                  Icon(Icons.bar_chart_rounded, size: 14, color: Theme.of(context).textTheme.bodySmall?.color),
                  const SizedBox(width: 4),
                  Text(topic.difficulty.label, style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
              const SizedBox(height: 30),

              Text('Your Learning Journey', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 14),

              JourneyActionButton(
                label: '📖  Learn',
                emoji: '📖',
                subtitle: 'AI-powered explanation by Claude',
                color: AppColors.primary,
                onTap: () => context.push(AppRoutes.learnPath(topic.id)),
              ).animate().fadeIn(delay: 100.ms).moveX(begin: 12, end: 0),
              const SizedBox(height: 12),

              JourneyActionButton(
                label: '🎥  Watch Animation',
                emoji: '🎥',
                subtitle: 'Cinematic explainer video',
                color: AppColors.secondary,
                onTap: () => context.push(AppRoutes.animationPath(topic.id)),
              ).animate().fadeIn(delay: 180.ms).moveX(begin: 12, end: 0),
              const SizedBox(height: 12),

              JourneyActionButton(
                label: '🎮  Interactive Experiment',
                emoji: '🎮',
                subtitle: 'Change variables, see results live',
                color: AppColors.accent,
                onTap: () => context.push(AppRoutes.experimentPath(topic.id)),
              ).animate().fadeIn(delay: 260.ms).moveX(begin: 12, end: 0),
              const SizedBox(height: 12),

              JourneyActionButton(
                label: '❓  Quiz',
                emoji: '❓',
                subtitle: 'Test your understanding',
                color: AppColors.error,
                onTap: () => context.push(AppRoutes.quizPath(topic.id)),
              ).animate().fadeIn(delay: 340.ms).moveX(begin: 12, end: 0),

              const SizedBox(height: 26),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardTheme.color,
                  borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                  border: Border.all(color: Theme.of(context).dividerColor),
                ),
                child: Row(
                  children: [
                    const Text('🏅', style: TextStyle(fontSize: 22)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Complete all four stages to master this topic and unlock the next one.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(delay: 420.ms),
            ],
          );
        },
      ),
    );
  }
}
