/// AnimationService is the integration point for Higgsfield-generated
/// cinematic educational videos.
///
/// TODAY: returns a status + placeholder asset so the "Watch" screen can
/// show a realistic loading -> ready flow without a real backend.
///
/// FUTURE: this will call the Higgsfield API with a rendering job for
/// [animationPromptKey], poll for completion, and return a real video URL,
/// e.g.:
///
///   final job = await higgsfieldClient.createRender(prompt: prompt);
///   final status = await higgsfieldClient.pollJob(job.id);
///   return AnimationResult(status: AnimationJobStatus.ready, videoUrl: status.url);
enum AnimationJobStatus { generating, ready, failed }

class AnimationResult {
  final AnimationJobStatus status;
  final String? videoUrl;
  final String? thumbnailEmoji;

  const AnimationResult({required this.status, this.videoUrl, this.thumbnailEmoji});
}

abstract class AnimationService {
  Future<AnimationResult> getAnimation(String animationPromptKey);
}

class MockAnimationService implements AnimationService {
  @override
  Future<AnimationResult> getAnimation(String animationPromptKey) async {
    // Simulates a Higgsfield generation/render job.
    await Future.delayed(const Duration(seconds: 2));
    return const AnimationResult(
      status: AnimationJobStatus.ready,
      videoUrl: null, // no real video yet — placeholder player is shown
      thumbnailEmoji: '🎬',
    );
  }
}
