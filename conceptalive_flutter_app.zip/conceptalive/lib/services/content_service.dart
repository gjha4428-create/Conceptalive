import 'package:flutter/material.dart';
import '../models/subject_model.dart';
import '../models/chapter_model.dart';
import '../models/topic_model.dart';

/// ContentService is the single gateway the UI uses to fetch subjects,
/// chapters, topics, and AI-generated explanations.
///
/// TODAY: it returns curated, hardcoded seed content (Force and Laws of
/// Motion) so the app works fully offline for the demo.
///
/// FUTURE: swap the body of `getLearnExplanation()` (and friends) to call
/// the Claude API — e.g.
///
///   final response = await claudeClient.messages.create(
///     model: 'claude-sonnet-5',
///     messages: [Message(role: 'user', content: buildPrompt(topic, grade))],
///   );
///
/// No screen needs to change because they only ever depend on this
/// service's method signatures, not on where the data comes from.
abstract class ContentService {
  Future<List<SubjectModel>> getSubjects();
  Future<List<ChapterModel>> getChaptersForSubject(String subjectId);
  Future<ChapterModel?> getChapterById(String chapterId);
  Future<TopicModel?> getTopicById(String topicId);

  /// Returns a grade-appropriate explanation for a topic.
  /// [gradeLevel] e.g. "Class 8" lets the same topic be explained at
  /// different reading levels — this is exactly the parameter that will
  /// be forwarded to the Claude API prompt in production.
  Future<String> getLearnExplanation({
    required String learnPromptKey,
    required String gradeLevel,
  });
}

/// Local, offline implementation used for the initial launch.
class LocalContentService implements ContentService {
  static final List<SubjectModel> _subjects = [
    const SubjectModel(
      id: 'science',
      name: 'Science',
      tagline: 'Explore the physical world',
      icon: Icons.science_rounded,
      gradientKey: 'science',
      totalChapters: 1,
      completedChapters: 0,
    ),
    const SubjectModel(
      id: 'math',
      name: 'Mathematics',
      tagline: 'Master numbers & logic',
      icon: Icons.calculate_rounded,
      gradientKey: 'math',
      totalChapters: 0,
      completedChapters: 0,
    ),
    const SubjectModel(
      id: 'sst',
      name: 'SST',
      tagline: 'History, geography & civics',
      icon: Icons.public_rounded,
      gradientKey: 'sst',
      totalChapters: 0,
      completedChapters: 0,
    ),
  ];

  static final List<ChapterModel> _chapters = [
    ChapterModel(
      id: 'force-and-laws-of-motion',
      subjectId: 'science',
      classLevel: 'Class 9',
      title: 'Force and Laws of Motion',
      description:
          'Discover why things move the way they do — from a ball rolling '
          'to a rocket launching — through Newton\'s three laws of motion.',
      coverEmoji: '🚀',
      difficulty: DifficultyLevel.medium,
      estimatedMinutes: 90,
      topics: [
        TopicModel(
          id: 'force',
          chapterId: 'force-and-laws-of-motion',
          orderIndex: 1,
          title: 'Force',
          shortDescription: 'What is a push or a pull, really?',
          heroEmoji: '👋',
          estimatedMinutes: 12,
          difficulty: DifficultyLevel.easy,
          progress: 1.0,
          isCompleted: true,
          learnPromptKey: 'force_intro',
          animationPromptKey: 'force_intro_anim',
          experimentType: 'push_pull_force',
          quizPromptKey: 'force_intro_quiz',
        ),
        TopicModel(
          id: 'balanced-unbalanced-forces',
          chapterId: 'force-and-laws-of-motion',
          orderIndex: 2,
          title: 'Balanced and Unbalanced Forces',
          shortDescription: 'Why a tug-of-war can end in a draw — or not.',
          heroEmoji: '⚖️',
          estimatedMinutes: 15,
          difficulty: DifficultyLevel.easy,
          progress: 0.4,
          learnPromptKey: 'balanced_forces',
          animationPromptKey: 'balanced_forces_anim',
          experimentType: 'balanced_forces',
          quizPromptKey: 'balanced_forces_quiz',
        ),
        TopicModel(
          id: 'newtons-first-law',
          chapterId: 'force-and-laws-of-motion',
          orderIndex: 3,
          title: "Newton's First Law",
          shortDescription: 'The law of inertia — objects love to keep doing what they\'re doing.',
          heroEmoji: '🛹',
          estimatedMinutes: 18,
          difficulty: DifficultyLevel.medium,
          progress: 0.0,
          learnPromptKey: 'newtons_first_law',
          animationPromptKey: 'newtons_first_law_anim',
          experimentType: 'inertia_sim',
          quizPromptKey: 'newtons_first_law_quiz',
        ),
        TopicModel(
          id: 'newtons-second-law',
          chapterId: 'force-and-laws-of-motion',
          orderIndex: 4,
          title: "Newton's Second Law",
          shortDescription: 'F = ma — how force, mass and acceleration connect.',
          heroEmoji: '🏎️',
          estimatedMinutes: 20,
          difficulty: DifficultyLevel.medium,
          isLocked: true,
          learnPromptKey: 'newtons_second_law',
          animationPromptKey: 'newtons_second_law_anim',
          experimentType: 'force_mass_acceleration',
          quizPromptKey: 'newtons_second_law_quiz',
        ),
        TopicModel(
          id: 'newtons-third-law',
          chapterId: 'force-and-laws-of-motion',
          orderIndex: 5,
          title: "Newton's Third Law",
          shortDescription: 'Every action has an equal and opposite reaction.',
          heroEmoji: '🎈',
          estimatedMinutes: 15,
          difficulty: DifficultyLevel.medium,
          isLocked: true,
          learnPromptKey: 'newtons_third_law',
          animationPromptKey: 'newtons_third_law_anim',
          experimentType: 'action_reaction',
          quizPromptKey: 'newtons_third_law_quiz',
        ),
        TopicModel(
          id: 'momentum',
          chapterId: 'force-and-laws-of-motion',
          orderIndex: 6,
          title: 'Momentum',
          shortDescription: 'Mass in motion — and why it\'s conserved in collisions.',
          heroEmoji: '🎱',
          estimatedMinutes: 20,
          difficulty: DifficultyLevel.hard,
          isLocked: true,
          learnPromptKey: 'momentum',
          animationPromptKey: 'momentum_anim',
          experimentType: 'momentum_collision',
          quizPromptKey: 'momentum_quiz',
        ),
      ],
    ),
  ];

  // Placeholder explanations — production will replace this map lookup
  // with a live Claude API call keyed by (learnPromptKey, gradeLevel).
  static final Map<String, String> _explanations = {
    'force_intro':
        'A force is simply a push or a pull. Every time you open a door, '
        'kick a ball, or pull a drawer, you are applying a force. Forces '
        'can start motion, stop motion, speed things up, slow them down, '
        'or change their direction — even change their shape, like squishing '
        'clay. In this chapter, we\'ll explore how forces shape everything '
        'that moves around us.',
    'balanced_forces':
        'When two teams pull equally hard in a tug-of-war, the rope doesn\'t '
        'move — the forces are "balanced." The moment one team pulls harder, '
        'the forces become "unbalanced," and the rope accelerates toward the '
        'stronger side. Balanced forces keep an object\'s motion unchanged; '
        'unbalanced forces are what cause acceleration.',
    'newtons_first_law':
        'Newton\'s First Law says an object at rest stays at rest, and an '
        'object in motion stays in motion at a constant velocity — unless an '
        'unbalanced force acts on it. This tendency to resist a change in '
        'motion is called inertia. It\'s why you lurch forward when a bus '
        'suddenly brakes — your body wants to keep moving!',
  };

  @override
  Future<List<SubjectModel>> getSubjects() async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _subjects;
  }

  @override
  Future<List<ChapterModel>> getChaptersForSubject(String subjectId) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _chapters.where((c) => c.subjectId == subjectId).toList();
  }

  @override
  Future<ChapterModel?> getChapterById(String chapterId) async {
    await Future.delayed(const Duration(milliseconds: 150));
    try {
      return _chapters.firstWhere((c) => c.id == chapterId);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<TopicModel?> getTopicById(String topicId) async {
    await Future.delayed(const Duration(milliseconds: 150));
    for (final chapter in _chapters) {
      for (final topic in chapter.topics) {
        if (topic.id == topicId) return topic;
      }
    }
    return null;
  }

  @override
  Future<String> getLearnExplanation({
    required String learnPromptKey,
    required String gradeLevel,
  }) async {
    // Simulated "AI thinking" latency — in production this is the Claude
    // API round-trip time, and the UI already shows a loading state for it.
    await Future.delayed(const Duration(milliseconds: 900));
    return _explanations[learnPromptKey] ??
        'Explanation coming soon! Once connected, Claude AI will generate '
        'a $gradeLevel-friendly explanation for this topic in real time.';
  }
}
