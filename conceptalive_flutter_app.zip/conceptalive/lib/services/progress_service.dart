import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_progress_model.dart';

/// ProgressService persists learner progress locally today, and is the
/// seam where Firebase Auth + Firestore sync will be added later:
/// simply swap the SharedPreferences calls below for Firestore reads/writes
/// while keeping the same method signatures, so providers/screens are
/// unaffected.
abstract class ProgressService {
  Future<UserProgressModel> loadProgress();
  Future<void> saveXp(int newTotalXp);
  Future<void> markTopicComplete(String topicId);
}

class LocalProgressService implements ProgressService {
  static const _xpKey = 'user_total_xp';
  static const _streakKey = 'user_streak_days';

  @override
  Future<UserProgressModel> loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final xp = prefs.getInt(_xpKey) ?? 240;
    final streak = prefs.getInt(_streakKey) ?? 4;

    return UserProgressModel(
      userName: 'Explorer',
      currentStreakDays: streak,
      longestStreakDays: streak > 7 ? streak : 7,
      totalXp: xp,
      level: (xp / 500).floor() + 1,
      activityLog: List.generate(
        streak,
        (i) => DateTime.now().subtract(Duration(days: i)),
      ),
      achievements: const [
        AchievementModel(
          id: 'first_topic',
          title: 'First Steps',
          description: 'Complete your first topic',
          emoji: '🌱',
          isUnlocked: true,
        ),
        AchievementModel(
          id: 'streak_3',
          title: 'On a Roll',
          description: '3-day learning streak',
          emoji: '🔥',
          isUnlocked: true,
        ),
        AchievementModel(
          id: 'quiz_ace',
          title: 'Quiz Ace',
          description: 'Score 100% on a quiz',
          emoji: '🎯',
          isUnlocked: false,
        ),
        AchievementModel(
          id: 'chapter_master',
          title: 'Chapter Master',
          description: 'Complete an entire chapter',
          emoji: '🏆',
          isUnlocked: false,
        ),
      ],
      chapterProgress: const {'force-and-laws-of-motion': 0.23},
    );
  }

  @override
  Future<void> saveXp(int newTotalXp) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_xpKey, newTotalXp);
  }

  @override
  Future<void> markTopicComplete(String topicId) async {
    // Placeholder — production writes completion + timestamp to Firestore.
    return;
  }
}
