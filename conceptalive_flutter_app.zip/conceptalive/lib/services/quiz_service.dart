import '../models/quiz_model.dart';

/// QuizService is the integration point for Claude-generated adaptive
/// quizzes.
///
/// TODAY: returns a curated placeholder question bank per topic.
///
/// FUTURE: `generateQuiz` will call the Claude API with the student's
/// mastery signals (past scores, time spent, weak sub-concepts) so that
/// question difficulty adapts automatically — the method signature below
/// already accepts `masteryLevel` for that purpose.
abstract class QuizService {
  Future<QuizModel> generateQuiz({
    required String quizPromptKey,
    double masteryLevel = 0.5,
  });
}

class LocalQuizService implements QuizService {
  static final Map<String, List<QuizQuestion>> _bank = {
    'force_intro_quiz': [
      const QuizQuestion(
        id: 'q1',
        question: 'Which of these is an example of a force?',
        options: ['Sunlight passing through glass', 'Kicking a football', 'A clock ticking', 'Water boiling'],
        correctIndex: 1,
        explanation: 'Kicking a football applies a push — a force — that changes its motion.',
      ),
      const QuizQuestion(
        id: 'q2',
        question: 'A force can change all of these EXCEPT:',
        options: ['Speed of an object', 'Direction of an object', 'Shape of an object', 'Color of an object'],
        correctIndex: 3,
        explanation: 'Forces affect motion and shape, but not the color of an object.',
      ),
      const QuizQuestion(
        id: 'q3',
        question: 'Which statement best defines force?',
        options: ['A type of energy', 'A push or a pull', 'A measure of speed', 'A type of friction'],
        correctIndex: 1,
        explanation: 'Force is fundamentally a push or a pull on an object.',
      ),
    ],
    'newtons_first_law_quiz': [
      const QuizQuestion(
        id: 'q1',
        question: 'Newton\'s First Law is also known as the law of:',
        options: ['Gravity', 'Inertia', 'Momentum', 'Friction'],
        correctIndex: 1,
        explanation: 'It describes an object\'s natural resistance to changes in motion — inertia.',
      ),
      const QuizQuestion(
        id: 'q2',
        question: 'Why do passengers lurch forward when a car brakes suddenly?',
        options: [
          'The car pushes them forward',
          'Their bodies want to keep moving due to inertia',
          'Gravity pulls them forward',
          'The seatbelt pushes them',
        ],
        correctIndex: 1,
        explanation: 'Their bodies were in motion and resist the sudden change — that\'s inertia in action.',
      ),
    ],
  };

  @override
  Future<QuizModel> generateQuiz({
    required String quizPromptKey,
    double masteryLevel = 0.5,
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));
    final questions = _bank[quizPromptKey] ??
        const [
          QuizQuestion(
            id: 'placeholder',
            question: 'Quiz questions for this topic are coming soon!',
            options: ['OK', 'Got it', 'Sounds good', 'Continue'],
            correctIndex: 0,
            explanation: 'Once connected, Claude AI will generate adaptive questions here.',
          ),
        ];
    return QuizModel(id: quizPromptKey, topicId: quizPromptKey, questions: questions);
  }
}
