import 'package:flutter/material.dart';

/// Central color palette for ConceptAlive.
/// Every screen should pull colors from here — never hardcode hex values
/// inline — so the whole app can be re-themed (e.g. per-subject accent
/// colors) without touching screen code.
class AppColors {
  AppColors._();

  // Brand
  static const Color primary = Color(0xFF6C5CE7); // violet
  static const Color primaryDark = Color(0xFF4834D4);
  static const Color secondary = Color(0xFF00D4B8); // teal/mint
  static const Color accent = Color(0xFFFF9F43); // warm orange (energy/XP)

  // Subject accent colors (used for gradients & badges per subject)
  static const Color scienceStart = Color(0xFF6C5CE7);
  static const Color scienceEnd = Color(0xFF00D4B8);
  static const Color mathStart = Color(0xFFFF6B6B);
  static const Color mathEnd = Color(0xFFFFA502);

  // Semantic
  static const Color success = Color(0xFF2ECC71);
  static const Color warning = Color(0xFFFFC048);
  static const Color error = Color(0xFFFF5E5E);
  static const Color info = Color(0xFF54A0FF);

  // Streak / gamification
  static const Color streakFlame = Color(0xFFFF7F50);
  static const Color xpGold = Color(0xFFFFD166);

  // Light theme neutrals
  static const Color lightBg = Color(0xFFF7F7FB);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightCard = Color(0xFFFFFFFF);
  static const Color lightBorder = Color(0xFFEAEAF2);
  static const Color lightTextPrimary = Color(0xFF1A1A2E);
  static const Color lightTextSecondary = Color(0xFF6B6B80);

  // Dark theme neutrals
  static const Color darkBg = Color(0xFF0F0F1A);
  static const Color darkSurface = Color(0xFF17172B);
  static const Color darkCard = Color(0xFF1E1E36);
  static const Color darkBorder = Color(0xFF2C2C45);
  static const Color darkTextPrimary = Color(0xFFF2F2F7);
  static const Color darkTextSecondary = Color(0xFFA0A0B8);

  // Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primary, primaryDark],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient scienceGradient = LinearGradient(
    colors: [scienceStart, scienceEnd],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient mathGradient = LinearGradient(
    colors: [mathStart, mathEnd],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient streakGradient = LinearGradient(
    colors: [Color(0xFFFF7F50), Color(0xFFFFB142)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient heroDarkGradient = LinearGradient(
    colors: [Color(0xFF1E1E36), Color(0xFF0F0F1A)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  /// Returns the gradient associated with a subject id ("science" | "math").
  static LinearGradient gradientForSubject(String subjectId) {
    switch (subjectId) {
      case 'math':
        return mathGradient;
      case 'science':
      default:
        return scienceGradient;
    }
  }
}
