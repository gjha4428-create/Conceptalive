import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// Premium typography system. Headlines use a rounded, friendly display
/// font (Baloo 2) to feel playful/Duolingo-like; body copy uses Inter for
/// clean, Apple-like readability.
class AppTextStyles {
  AppTextStyles._();

  static TextStyle _display(double size, FontWeight w, Color c) =>
      GoogleFonts.baloo2(fontSize: size, fontWeight: w, color: c, height: 1.15);

  static TextStyle _body(double size, FontWeight w, Color c) =>
      GoogleFonts.inter(fontSize: size, fontWeight: w, color: c, height: 1.4);

  static TextTheme textTheme(bool isDark) {
    final primaryText = isDark ? AppColors.darkTextPrimary : AppColors.lightTextPrimary;
    final secondaryText = isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary;

    return TextTheme(
      displayLarge: _display(34, FontWeight.w700, primaryText),
      displayMedium: _display(28, FontWeight.w700, primaryText),
      displaySmall: _display(24, FontWeight.w700, primaryText),
      headlineMedium: _display(20, FontWeight.w600, primaryText),
      headlineSmall: _display(18, FontWeight.w600, primaryText),
      titleLarge: _body(17, FontWeight.w700, primaryText),
      titleMedium: _body(15, FontWeight.w600, primaryText),
      titleSmall: _body(13, FontWeight.w600, secondaryText),
      bodyLarge: _body(16, FontWeight.w400, primaryText),
      bodyMedium: _body(14, FontWeight.w400, secondaryText),
      bodySmall: _body(12, FontWeight.w400, secondaryText),
      labelLarge: _body(14, FontWeight.w600, primaryText),
    );
  }
}
