class AppConstants {
  AppConstants._();

  static const String appName = 'ConceptAlive';
  static const String tagline = 'See. Explore. Understand.';
  static const String defaultGradeLevel = 'Class 9';

  static const double screenPaddingH = 20;
}
