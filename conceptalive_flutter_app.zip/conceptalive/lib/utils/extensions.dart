extension DurationLabel on int {
  /// Converts minutes -> "18 min" style label.
  String get asMinutesLabel => '$this min';
}

extension DoublePercent on double {
  int get asPercent => (this * 100).round();
}
