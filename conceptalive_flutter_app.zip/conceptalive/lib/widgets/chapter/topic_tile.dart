import 'package:flutter/material.dart';
import '../../models/topic_model.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../utils/extensions.dart';
import '../common/progress_ring.dart';

class TopicTile extends StatelessWidget {
  final TopicModel topic;
  final VoidCallback onTap;

  const TopicTile({super.key, required this.topic, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final locked = topic.isLocked;

    return Material(
      color: theme.cardTheme.color,
      borderRadius: BorderRadius.circular(AppTheme.radiusMd),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        onTap: locked ? null : onTap,
        child: Opacity(
          opacity: locked ? 0.55 : 1,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppTheme.radiusMd),
              border: Border.all(color: theme.dividerColor),
            ),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Text(topic.heroEmoji, style: const TextStyle(fontSize: 22)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 20,
                            height: 20,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: AppColors.primary.withValues(alpha: 0.12),
                              shape: BoxShape.circle,
                            ),
                            child: Text('${topic.orderIndex}',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.primary)),
                          ),
                          const SizedBox(width: 8),
                          Expanded(child: Text(topic.title, style: theme.textTheme.titleMedium)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(topic.shortDescription,
                          maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Icon(Icons.timer_outlined, size: 12, color: theme.textTheme.bodySmall?.color),
                          const SizedBox(width: 4),
                          Text(topic.estimatedMinutes.asMinutesLabel,
                              style: theme.textTheme.bodySmall?.copyWith(fontSize: 11)),
                          const SizedBox(width: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.warning.withValues(alpha: 0.16),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(topic.difficulty.label,
                                style: const TextStyle(fontSize: 10, color: Color(0xFFB8860B), fontWeight: FontWeight.w600)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                locked
                    ? const Icon(Icons.lock_rounded, color: Colors.grey)
                    : topic.isCompleted
                        ? const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 28)
                        : ProgressRing(percent: topic.progress, radius: 16, color: AppColors.secondary),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
