import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import '../../theme/app_colors.dart';

class ProgressRing extends StatelessWidget {
  final double percent; // 0..1
  final double radius;
  final Color color;
  final Widget? center;

  const ProgressRing({
    super.key,
    required this.percent,
    this.radius = 26,
    this.color = AppColors.primary,
    this.center,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return CircularPercentIndicator(
      radius: radius,
      lineWidth: 6,
      percent: percent.clamp(0.0, 1.0),
      animation: true,
      animationDuration: 700,
      circularStrokeCap: CircularStrokeCap.round,
      backgroundColor: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.08),
      progressColor: color,
      center: center,
    );
  }
}
