import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';

class StreakWidget extends StatelessWidget {
  final int streakDays;
  final int totalXp;

  const StreakWidget({super.key, required this.streakDays, required this.totalXp});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _StatPill(
            emoji: '🔥',
            value: '$streakDays',
            label: streakDays == 1 ? 'day streak' : 'day streak',
            gradient: AppColors.streakGradient,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _StatPill(
            emoji: '⭐',
            value: '$totalXp',
            label: 'total XP',
            gradient: const LinearGradient(colors: [Color(0xFF54A0FF), Color(0xFF6C5CE7)]),
          ),
        ),
      ],
    );
  }
}

class _StatPill extends StatelessWidget {
  final String emoji;
  final String value;
  final String label;
  final Gradient gradient;

  const _StatPill({required this.emoji, required this.value, required this.label, required this.gradient});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
      ),
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 24)).animate(onPlay: (c) => c.repeat(reverse: true))
              .scale(duration: 900.ms, begin: const Offset(1, 1), end: const Offset(1.12, 1.12)),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
              Text(label, style: TextStyle(color: Colors.white.withValues(alpha: 0.9), fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}
