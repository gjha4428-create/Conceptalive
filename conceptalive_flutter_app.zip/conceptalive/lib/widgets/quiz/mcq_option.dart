import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';

enum McqOptionState { normal, selected, correct, incorrect }

class McqOption extends StatelessWidget {
  final String label;
  final String text;
  final McqOptionState state;
  final VoidCallback? onTap;

  const McqOption({
    super.key,
    required this.label,
    required this.text,
    required this.state,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Color borderColor;
    Color bgColor;
    Color labelColor = Colors.white;
    IconData? trailingIcon;

    final theme = Theme.of(context);
    switch (state) {
      case McqOptionState.normal:
        borderColor = theme.dividerColor;
        bgColor = theme.cardTheme.color ?? Colors.white;
        labelColor = AppColors.primary;
        break;
      case McqOptionState.selected:
        borderColor = AppColors.primary;
        bgColor = AppColors.primary.withValues(alpha: 0.08);
        labelColor = AppColors.primary;
        break;
      case McqOptionState.correct:
        borderColor = AppColors.success;
        bgColor = AppColors.success.withValues(alpha: 0.12);
        labelColor = AppColors.success;
        trailingIcon = Icons.check_circle_rounded;
        break;
      case McqOptionState.incorrect:
        borderColor = AppColors.error;
        bgColor = AppColors.error.withValues(alpha: 0.1);
        labelColor = AppColors.error;
        trailingIcon = Icons.cancel_rounded;
        break;
    }

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(AppTheme.radiusMd),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(AppTheme.radiusMd),
            border: Border.all(color: borderColor, width: state == McqOptionState.normal ? 1 : 1.6),
          ),
          child: Row(
            children: [
              Container(
                width: 30,
                height: 30,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: borderColor.withValues(alpha: state == McqOptionState.normal ? 0.1 : 1),
                  shape: BoxShape.circle,
                ),
                child: Text(label,
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: state == McqOptionState.normal ? labelColor : Colors.white)),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(text, style: theme.textTheme.bodyLarge)),
              if (trailingIcon != null) Icon(trailingIcon, color: borderColor, size: 22),
            ],
          ),
        ),
      ),
    );
  }
}
